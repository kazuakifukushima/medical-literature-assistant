import React, { useState, useEffect } from 'react';
import { 
  ExternalLink, 
  Calendar, 
  Users, 
  BookOpen, 
  Star, 
  Download, 
  Play,
  Clock,
  Award,
  TrendingUp,
  Eye,
  Share2,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Database,
  Globe
} from 'lucide-react';
import { fetchIntegratedNEJMData, NEJMArticleData } from '../services/nejm-api';

interface FetchStatus {
  isLoading: boolean;
  lastUpdated: string | null;
  error: string | null;
  sources: {
    nejm: boolean;
    pubmed: boolean;
  };
}

const NEJMSection: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<NEJMArticleData | null>(null);
  const [activeCategory, setActiveCategory] = useState('all');
  const [articles, setArticles] = useState<NEJMArticleData[]>([]);
  const [fetchStatus, setFetchStatus] = useState<FetchStatus>({
    isLoading: false,
    lastUpdated: null,
    error: null,
    sources: {
      nejm: false,
      pubmed: false
    }
  });

  // データ取得関数
  const loadLatestArticles = async () => {
    setFetchStatus(prev => ({ 
      ...prev, 
      isLoading: true, 
      error: null,
      sources: { nejm: false, pubmed: false }
    }));
    
    try {
      console.log('🔄 NEJM統合データ取得を開始...');
      const latestArticles = await fetchIntegratedNEJMData();
      
      setArticles(latestArticles);
      setFetchStatus({
        isLoading: false,
        lastUpdated: new Date().toLocaleString('ja-JP'),
        error: null,
        sources: {
          nejm: latestArticles.some(a => a.source === 'nejm'),
          pubmed: latestArticles.some(a => a.source === 'pubmed')
        }
      });
      
      console.log(`✅ ${latestArticles.length}件の論文データを取得完了`);
    } catch (error) {
      console.error('❌ データ取得エラー:', error);
      setFetchStatus({
        isLoading: false,
        lastUpdated: null,
        error: 'データの取得に失敗しました。ネットワーク接続を確認してください。',
        sources: { nejm: false, pubmed: false }
      });
    }
  };

  // ブラウザ開始時のみデータを取得（自動更新なし）
  useEffect(() => {
    loadLatestArticles();
  }, []); // 依存配列を空にして初回のみ実行

  const categories = [
    { id: 'all', label: '全ての記事', count: articles.length },
    { id: 'Original Article', label: 'Original Articles', count: articles.filter(a => a.category === 'Original Article').length },
    { id: 'Review Article', label: 'Review Articles', count: articles.filter(a => a.category === 'Review Article').length },
    { id: 'Case Report', label: 'Case Reports', count: articles.filter(a => a.category === 'Case Report').length },
    { id: 'Editorial', label: 'Editorials', count: articles.filter(a => a.category === 'Editorial').length },
    { id: 'Correspondence', label: 'Correspondence', count: articles.filter(a => a.category === 'Correspondence').length }
  ];

  const filteredArticles = activeCategory === 'all' 
    ? articles 
    : articles.filter(article => article.category === activeCategory);

  const getEvidenceBadgeColor = (level: string) => {
    switch (level) {
      case 'A': return 'bg-green-500/20 text-green-300 border border-green-400/30';
      case 'B': return 'bg-yellow-500/20 text-yellow-300 border border-yellow-400/30';
      case 'C': return 'bg-red-500/20 text-red-300 border border-red-400/30';
      default: return 'bg-gray-500/20 text-gray-300 border border-gray-400/30';
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'nejm': return <Globe className="h-3 w-3" />;
      case 'pubmed': return <Database className="h-3 w-3" />;
      default: return <BookOpen className="h-3 w-3" />;
    }
  };

  const getSourceColor = (source: string) => {
    switch (source) {
      case 'nejm': return 'bg-red-500/20 text-red-300 border border-red-400/30';
      case 'pubmed': return 'bg-blue-500/20 text-blue-300 border border-blue-400/30';
      default: return 'bg-gray-500/20 text-gray-300 border border-gray-400/30';
    }
  };

  return (
    <div className="space-y-8">
      {/* NEJM Header with Integrated Data Status */}
      <div className="bg-gradient-to-r from-red-900/20 to-blue-900/20 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="w-20 h-20 bg-gradient-to-br from-red-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-lg">NEJM</span>
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">New England Journal of Medicine</h2>
              <div className="flex items-center space-x-6 text-white/80">
                <div className="flex items-center space-x-2">
                  <Award className="h-5 w-5 text-yellow-400" />
                  <span className="font-semibold">Impact Factor: 176.079</span>
                </div>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-green-400" />
                  <span>統合データソース対応</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-blue-400" />
                  <span>リアルタイム更新</span>
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {/* Data Source Status */}
            <div className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
              <div className="flex items-center space-x-1">
                <Globe className={`h-4 w-4 ${fetchStatus.sources.nejm ? 'text-green-400' : 'text-gray-400'}`} />
                <span className="text-xs text-white/80">NEJM</span>
              </div>
              <div className="w-px h-4 bg-white/20"></div>
              <div className="flex items-center space-x-1">
                <Database className={`h-4 w-4 ${fetchStatus.sources.pubmed ? 'text-green-400' : 'text-gray-400'}`} />
                <span className="text-xs text-white/80">PubMed</span>
              </div>
            </div>

            {/* Real-time Status Indicator */}
            <div className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
              {fetchStatus.isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 text-blue-400 animate-spin" />
                  <span className="text-sm text-blue-200">統合中...</span>
                </>
              ) : fetchStatus.error ? (
                <>
                  <AlertCircle className="h-4 w-4 text-red-400" />
                  <span className="text-sm text-red-200">エラー</span>
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span className="text-sm text-green-200">最新</span>
                </>
              )}
            </div>
            
            {/* Manual Refresh Button */}
            <button
              onClick={loadLatestArticles}
              disabled={fetchStatus.isLoading}
              className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <RefreshCw className={`h-4 w-4 ${fetchStatus.isLoading ? 'animate-spin' : ''}`} />
              <span className="text-sm font-medium">統合更新</span>
            </button>
            
            <a 
              href="https://www.nejm.org/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-red-600 to-blue-600 text-white rounded-xl hover:from-red-700 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <ExternalLink className="h-5 w-5" />
              <span className="font-semibold">NEJM.org</span>
            </a>
          </div>
        </div>
        
        {/* Last Updated Info with Source Details */}
        {fetchStatus.lastUpdated && (
          <div className="mt-4 flex items-center justify-between">
            <div className="flex items-center space-x-2 text-sm text-white/60">
              <Clock className="h-4 w-4" />
              <span>最終更新: {fetchStatus.lastUpdated}</span>
              <span className="mx-2">•</span>
              <span>{articles.length} 件の統合論文</span>
            </div>
            <div className="flex items-center space-x-4 text-xs text-white/60">
              <div className="flex items-center space-x-1">
                <Globe className="h-3 w-3" />
                <span>NEJM直接: {articles.filter(a => a.source === 'nejm').length}件</span>
              </div>
              <div className="flex items-center space-x-1">
                <Database className="h-3 w-3" />
                <span>PubMed経由: {articles.filter(a => a.source === 'pubmed').length}件</span>
              </div>
            </div>
          </div>
        )}
        
        {/* Error Message */}
        {fetchStatus.error && (
          <div className="mt-4 p-4 bg-red-500/20 border border-red-400/30 rounded-xl">
            <div className="flex items-center space-x-2 text-red-200">
              <AlertCircle className="h-5 w-5" />
              <span className="font-medium">データ統合エラー</span>
            </div>
            <p className="text-sm text-red-300 mt-1">{fetchStatus.error}</p>
            <p className="text-xs text-red-400 mt-2">
              ※ フォールバックデータを表示しています。手動更新をお試しください。
            </p>
          </div>
        )}
      </div>

      {/* Category Filter */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-white mb-4">記事カテゴリー</h3>
        <div className="flex flex-wrap gap-3">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-4 py-2 rounded-xl transition-all duration-300 transform hover:scale-105 ${
                activeCategory === category.id
                  ? 'bg-gradient-to-r from-red-500/30 to-blue-500/30 text-white border border-red-400/50 shadow-lg'
                  : 'bg-white/10 text-white/80 hover:bg-white/20 border border-white/20'
              }`}
            >
              <span className="font-medium">{category.label}</span>
              {category.count > 0 && (
                <span className="ml-2 px-2 py-1 bg-white/20 rounded-full text-xs">
                  {category.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Loading State */}
      {fetchStatus.isLoading && articles.length === 0 && (
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-4 mb-4">
              <RefreshCw className="h-8 w-8 text-blue-400 animate-spin" />
              <div className="flex space-x-2">
                <Globe className="h-6 w-6 text-red-400 animate-pulse" />
                <Database className="h-6 w-6 text-blue-400 animate-pulse" />
              </div>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">統合データを取得中...</h3>
            <p className="text-white/70">NEJM公式サイトとPubMedから最新論文を収集しています</p>
          </div>
        </div>
      )}

      {/* Articles Grid */}
      {!fetchStatus.isLoading && (
        <div className="grid grid-cols-1 gap-8">
          {filteredArticles.map((article) => (
            <div 
              key={article.id}
              className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/20 overflow-hidden hover:bg-white/20 transition-all duration-500 transform hover:scale-[1.02] group"
            >
              <div className="p-8">
                {/* Article Header */}
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center space-x-4 flex-wrap">
                    <span className={`px-3 py-1 text-sm font-bold rounded-full ${getEvidenceBadgeColor(article.evidenceLevel)}`}>
                      Evidence Level {article.evidenceLevel}
                    </span>
                    <span className="px-3 py-1 text-sm font-medium bg-red-500/20 text-red-300 rounded-full border border-red-400/30">
                      {article.category}
                    </span>
                    <span className="px-3 py-1 text-sm font-medium bg-blue-500/20 text-blue-300 rounded-full border border-blue-400/30">
                      {article.specialty}
                    </span>
                    {/* Data Source Badge */}
                    <span className={`px-3 py-1 text-xs font-medium rounded-full flex items-center space-x-1 ${getSourceColor(article.source)}`}>
                      {getSourceIcon(article.source)}
                      <span>{article.source === 'nejm' ? 'NEJM直接' : 'PubMed経由'}</span>
                    </span>
                    {article.isOpenAccess && (
                      <span className="px-3 py-1 text-sm font-medium bg-green-500/20 text-green-300 rounded-full border border-green-400/30">
                        Open Access
                      </span>
                    )}
                    {/* New Article Indicator */}
                    {new Date(article.publishDate) > new Date(Date.now() - 24 * 60 * 60 * 1000) && (
                      <span className="px-3 py-1 text-sm font-bold bg-yellow-500/20 text-yellow-300 rounded-full border border-yellow-400/30 animate-pulse">
                        NEW
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-300">
                      <Star className="h-5 w-5" />
                    </button>
                    <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-300">
                      <Download className="h-5 w-5" />
                    </button>
                    <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-300">
                      <Share2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-blue-200 transition-colors cursor-pointer"
                    onClick={() => setSelectedArticle(article)}>
                  {article.title}
                </h3>

                {/* Authors */}
                <div className="flex items-center space-x-2 text-white/80 mb-4">
                  <Users className="h-4 w-4" />
                  <span className="text-sm">
                    {article.authors.slice(0, 3).join(', ')}
                    {article.authors.length > 3 && ` et al. (${article.authors.length} authors)`}
                  </span>
                </div>

                {/* Publication Info */}
                <div className="flex items-center space-x-6 text-sm text-white/70 mb-6">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>{article.publishDate}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <BookOpen className="h-4 w-4" />
                    <span>Vol. {article.volume}, No. {article.issue}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="h-4 w-4" />
                    <span>{article.readingTime}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <TrendingUp className="h-4 w-4" />
                    <span>{article.citationCount} citations</span>
                  </div>
                </div>

                {/* Summary */}
                <p className="text-white/90 leading-relaxed mb-6 text-lg">
                  {article.summary}
                </p>

                {/* Keywords */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {article.keywords.map((keyword, index) => (
                    <span 
                      key={index}
                      className="px-3 py-1 bg-white/10 text-white/80 rounded-full text-sm border border-white/20"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>

                {/* DOI and Actions */}
                <div className="flex justify-between items-center">
                  <div className="text-sm text-white/60">
                    <span className="font-medium">DOI: </span>
                    <a 
                      href={`https://doi.org/${article.doi}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-300 hover:text-blue-200 transition-colors"
                    >
                      {article.doi}
                    </a>
                  </div>
                  
                  <div className="flex space-x-3">
                    <button 
                      onClick={() => setSelectedArticle(article)}
                      className="px-6 py-3 bg-gradient-to-r from-red-600 to-blue-600 text-white rounded-xl hover:from-red-700 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg font-semibold"
                    >
                      詳細を読む
                    </button>
                    {article.url && (
                      <a
                        href={article.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 font-semibold flex items-center space-x-2"
                      >
                        {getSourceIcon(article.source)}
                        <span>{article.source === 'nejm' ? 'NEJM で読む' : 'PubMed で読む'}</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!fetchStatus.isLoading && filteredArticles.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="h-12 w-12 text-white/40 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">該当する論文が見つかりませんでした</h3>
          <p className="text-white/70">カテゴリーを変更するか、手動更新をお試しください</p>
        </div>
      )}

      {/* Article Detail Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl max-w-6xl w-full max-h-[90vh] overflow-y-auto border border-white/20 shadow-2xl transform animate-slideUp">
            <div className="p-8 border-b border-white/20 bg-gradient-to-r from-red-900/20 to-blue-900/20">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4 flex-wrap">
                  <span className={`px-3 py-1 text-sm font-bold rounded-full ${getEvidenceBadgeColor(selectedArticle.evidenceLevel)}`}>
                    Evidence Level {selectedArticle.evidenceLevel}
                  </span>
                  <span className="px-3 py-1 text-sm font-medium bg-red-500/20 text-red-300 rounded-full border border-red-400/30">
                    {selectedArticle.category}
                  </span>
                  <span className={`px-3 py-1 text-xs font-medium rounded-full flex items-center space-x-1 ${getSourceColor(selectedArticle.source)}`}>
                    {getSourceIcon(selectedArticle.source)}
                    <span>{selectedArticle.source === 'nejm' ? 'NEJM直接' : 'PubMed経由'}</span>
                  </span>
                  <span className="text-sm text-white/70">{selectedArticle.publishDate}</span>
                  {new Date(selectedArticle.publishDate) > new Date(Date.now() - 24 * 60 * 60 * 1000) && (
                    <span className="px-3 py-1 text-sm font-bold bg-yellow-500/20 text-yellow-300 rounded-full border border-yellow-400/30 animate-pulse">
                      NEW
                    </span>
                  )}
                </div>
                <button 
                  onClick={() => setSelectedArticle(null)}
                  className="text-white/60 hover:text-white text-2xl transform hover:scale-110 transition-all duration-300"
                >
                  ✕
                </button>
              </div>
              
              <h2 className="text-3xl font-bold text-white mb-4">{selectedArticle.title}</h2>
              
              <div className="flex items-center space-x-6 text-white/80">
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>{selectedArticle.authors.join(', ')}</span>
                </div>
              </div>
            </div>
            
            <div className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <h3 className="text-2xl font-bold text-white mb-6">要約</h3>
                  <p className="text-white/90 leading-relaxed mb-8 text-lg">
                    {selectedArticle.summary}
                  </p>
                  
                  <h3 className="text-2xl font-bold text-white mb-6">本文</h3>
                  <div className="text-white/90 leading-relaxed space-y-4">
                    {selectedArticle.fullText.split('\n').map((paragraph, index) => (
                      <p key={index} className="text-lg">{paragraph}</p>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                    <h4 className="text-lg font-bold text-white mb-4">論文情報</h4>
                    <div className="space-y-3 text-sm">
                      <div>
                        <span className="text-white/60">データソース: </span>
                        <div className="flex items-center space-x-1 mt-1">
                          {getSourceIcon(selectedArticle.source)}
                          <span className="text-white">{selectedArticle.source === 'nejm' ? 'NEJM公式' : 'PubMed API'}</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-white/60">Volume: </span>
                        <span className="text-white">{selectedArticle.volume}</span>
                      </div>
                      <div>
                        <span className="text-white/60">Issue: </span>
                        <span className="text-white">{selectedArticle.issue}</span>
                      </div>
                      <div>
                        <span className="text-white/60">Pages: </span>
                        <span className="text-white">{selectedArticle.pages}</span>
                      </div>
                      <div>
                        <span className="text-white/60">DOI: </span>
                        <a 
                          href={`https://doi.org/${selectedArticle.doi}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-300 hover:text-blue-200 transition-colors break-all"
                        >
                          {selectedArticle.doi}
                        </a>
                      </div>
                      <div>
                        <span className="text-white/60">Citations: </span>
                        <span className="text-white">{selectedArticle.citationCount}</span>
                      </div>
                      <div>
                        <span className="text-white/60">Reading Time: </span>
                        <span className="text-white">{selectedArticle.readingTime}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                    <h4 className="text-lg font-bold text-white mb-4">キーワード</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedArticle.keywords.map((keyword, index) => (
                        <span 
                          key={index}
                          className="px-3 py-1 bg-white/10 text-white/80 rounded-full text-sm border border-white/20"
                        >
                          {keyword}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    {selectedArticle.url && (
                      <a
                        href={selectedArticle.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-red-600 to-blue-600 text-white rounded-xl hover:from-red-700 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg font-semibold"
                      >
                        <ExternalLink className="h-4 w-4" />
                        <span>{selectedArticle.source === 'nejm' ? 'NEJM で全文を読む' : 'PubMed で詳細を見る'}</span>
                      </a>
                    )}
                    <button className="w-full px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 font-semibold">
                      お気に入りに追加
                    </button>
                    <button className="w-full px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 font-semibold">
                      引用情報をコピー
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NEJMSection;