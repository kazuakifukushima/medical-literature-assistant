import React from 'react';
import { 
  Home, 
  BookOpen, 
  Filter, 
  Star, 
  Download, 
  TrendingUp, 
  Settings,
  Heart,
  Brain,
  Activity,
  Users,
  Eye,
  Scissors,
  FileText,
  Microscope,
  Stethoscope,
  Zap,
  Shield,
  Baby,
  Bone,
  Pill,
  Syringe,
  Thermometer,
  Waves,
  ChevronDown,
  ChevronRight
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  selectedSpecialty: string;
  onSpecialtyChange: (specialty: string) => void;
  selectedJournals: string[];
  onJournalChange: (journals: string[]) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  activeTab, 
  onTabChange, 
  selectedSpecialty, 
  onSpecialtyChange,
  selectedJournals,
  onJournalChange
}) => {
  const [isSpecialtyExpanded, setIsSpecialtyExpanded] = React.useState(true);
  const [isJournalExpanded, setIsJournalExpanded] = React.useState(true);

  const mainNavigation = [
    { id: 'dashboard', label: 'ダッシュボード', icon: Home },
    { id: 'articles', label: '論文フィード', icon: BookOpen },
    { id: 'favorites', label: 'お気に入り', icon: Star },
    { id: 'analytics', label: 'トレンド分析', icon: TrendingUp },
    { id: 'exports', label: 'エクスポート', icon: Download },
    { id: 'settings', label: '設定', icon: Settings },
  ];

  const specialties = [
    { id: 'all', label: '全て', icon: Filter },
    { id: 'internal-medicine', label: '内科', icon: Stethoscope },
    { id: 'cardiology', label: '循環器科', icon: Heart },
    { id: 'neurology', label: '神経内科', icon: Brain },
    { id: 'gastroenterology', label: '消化器科', icon: Pill },
    { id: 'endocrinology', label: '内分泌科', icon: Thermometer },
    { id: 'pulmonology', label: '呼吸器科', icon: Activity },
    { id: 'nephrology', label: '腎臓内科', icon: Waves },
    { id: 'hematology', label: '血液内科', icon: Syringe },
    { id: 'rheumatology', label: 'リウマチ科', icon: Bone },
    { id: 'dermatology', label: '皮膚科', icon: Shield },
    { id: 'emergency', label: '救急医学', icon: Activity },
    { id: 'pediatrics', label: '小児科', icon: Users },
    { id: 'ophthalmology', label: '眼科', icon: Eye },
    { id: 'surgery', label: '外科', icon: Scissors },
    { id: 'oncology', label: '腫瘍科', icon: Zap },
    { id: 'infectious', label: '感染症科', icon: Shield },
    { id: 'orthopedics', label: '整形外科', icon: Bone },
    { id: 'psychiatry', label: '精神科', icon: Brain },
    { id: 'radiology', label: '放射線科', icon: Waves },
    { id: 'anesthesiology', label: '麻酔科', icon: Activity },
    { id: 'pathology', label: '病理科', icon: Microscope },
    { id: 'urology', label: '泌尿器科', icon: Waves },
    { id: 'obstetrics', label: '産婦人科', icon: Baby },
    { id: 'ent', label: '耳鼻咽喉科', icon: Activity },
    { id: 'plastic-surgery', label: '形成外科', icon: Scissors },
  ];

  // 専門分野別の主要雑誌データ
  const journalsBySpecialty = {
    all: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'nature-medicine', label: 'Nature Medicine', icon: Microscope },
      { id: 'science', label: 'Science', icon: Brain },
      { id: 'cell', label: 'Cell', icon: Activity },
    ],
    'internal-medicine': [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'jama-internal', label: 'JAMA Internal Medicine', icon: Stethoscope },
      { id: 'arch-internal', label: 'Archives of Internal Medicine', icon: Stethoscope },
      { id: 'mayo-clinic', label: 'Mayo Clinic Proceedings', icon: Stethoscope },
      { id: 'cleveland-clinic', label: 'Cleveland Clinic Journal', icon: Stethoscope },
    ],
    cardiology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'circulation', label: 'Circulation', icon: Heart },
      { id: 'jacc', label: 'JACC', icon: Heart },
      { id: 'eur-heart-j', label: 'European Heart Journal', icon: Heart },
      { id: 'jama-cardiology', label: 'JAMA Cardiology', icon: Heart },
      { id: 'nature-medicine', label: 'Nature Medicine', icon: Microscope },
      { id: 'heart', label: 'Heart', icon: Heart },
      { id: 'circ-research', label: 'Circulation Research', icon: Heart },
      { id: 'arteriosclerosis', label: 'Arteriosclerosis, Thrombosis, and Vascular Biology', icon: Heart },
    ],
    gastroenterology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'gastroenterology', label: 'Gastroenterology', icon: Pill },
      { id: 'gut', label: 'Gut', icon: Pill },
      { id: 'hepatology', label: 'Hepatology', icon: Pill },
      { id: 'jama-gastro', label: 'JAMA Gastroenterology', icon: Pill },
      { id: 'lancet-gastro', label: 'Lancet Gastroenterology & Hepatology', icon: Pill },
      { id: 'gi-endoscopy', label: 'Gastrointestinal Endoscopy', icon: Pill },
    ],
    endocrinology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'diabetes-care', label: 'Diabetes Care', icon: Thermometer },
      { id: 'diabetes', label: 'Diabetes', icon: Thermometer },
      { id: 'jcem', label: 'Journal of Clinical Endocrinology & Metabolism', icon: Thermometer },
      { id: 'lancet-diabetes', label: 'Lancet Diabetes & Endocrinology', icon: Thermometer },
      { id: 'diabetologia', label: 'Diabetologia', icon: Thermometer },
    ],
    pulmonology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'ajrccm', label: 'American Journal of Respiratory and Critical Care Medicine', icon: Activity },
      { id: 'thorax', label: 'Thorax', icon: Activity },
      { id: 'chest', label: 'Chest', icon: Activity },
      { id: 'lancet-respiratory', label: 'Lancet Respiratory Medicine', icon: Activity },
      { id: 'respirology', label: 'Respirology', icon: Activity },
    ],
    nephrology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'jasn', label: 'Journal of the American Society of Nephrology', icon: Waves },
      { id: 'kidney-int', label: 'Kidney International', icon: Waves },
      { id: 'ajkd', label: 'American Journal of Kidney Diseases', icon: Waves },
      { id: 'nephrology', label: 'Nephrology', icon: Waves },
    ],
    hematology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'blood', label: 'Blood', icon: Syringe },
      { id: 'lancet-haematology', label: 'Lancet Haematology', icon: Syringe },
      { id: 'leukemia', label: 'Leukemia', icon: Syringe },
      { id: 'haematologica', label: 'Haematologica', icon: Syringe },
      { id: 'bjh', label: 'British Journal of Haematology', icon: Syringe },
    ],
    rheumatology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'ann-rheum-dis', label: 'Annals of the Rheumatic Diseases', icon: Bone },
      { id: 'arthritis-rheum', label: 'Arthritis & Rheumatism', icon: Bone },
      { id: 'lancet-rheumatology', label: 'Lancet Rheumatology', icon: Bone },
      { id: 'rheumatology', label: 'Rheumatology', icon: Bone },
    ],
    dermatology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'jama-dermatology', label: 'JAMA Dermatology', icon: Shield },
      { id: 'jaad', label: 'Journal of the American Academy of Dermatology', icon: Shield },
      { id: 'bjd', label: 'British Journal of Dermatology', icon: Shield },
      { id: 'jid', label: 'Journal of Investigative Dermatology', icon: Shield },
    ],
    neurology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'neuron', label: 'Neuron', icon: Brain },
      { id: 'nature-neuroscience', label: 'Nature Neuroscience', icon: Brain },
      { id: 'lancet-neurology', label: 'Lancet Neurology', icon: Brain },
      { id: 'jama-neurology', label: 'JAMA Neurology', icon: Brain },
      { id: 'brain', label: 'Brain', icon: Brain },
      { id: 'annals-neurology', label: 'Annals of Neurology', icon: Brain },
      { id: 'stroke', label: 'Stroke', icon: Brain },
      { id: 'movement-disorders', label: 'Movement Disorders', icon: Brain },
      { id: 'epilepsia', label: 'Epilepsia', icon: Brain },
    ],
    emergency: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'annals-emergency', label: 'Annals of Emergency Medicine', icon: Activity },
      { id: 'academic-emergency', label: 'Academic Emergency Medicine', icon: Activity },
      { id: 'emergency-medicine', label: 'Emergency Medicine Journal', icon: Activity },
      { id: 'resuscitation', label: 'Resuscitation', icon: Activity },
      { id: 'critical-care', label: 'Critical Care Medicine', icon: Activity },
      { id: 'intensive-care', label: 'Intensive Care Medicine', icon: Activity },
    ],
    pediatrics: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'pediatrics', label: 'Pediatrics', icon: Baby },
      { id: 'jama-pediatrics', label: 'JAMA Pediatrics', icon: Baby },
      { id: 'lancet-child', label: 'Lancet Child & Adolescent Health', icon: Baby },
      { id: 'nature-medicine', label: 'Nature Medicine', icon: Microscope },
      { id: 'arch-pediatrics', label: 'Archives of Pediatrics', icon: Baby },
      { id: 'jpeds', label: 'Journal of Pediatrics', icon: Baby },
      { id: 'pediatric-research', label: 'Pediatric Research', icon: Baby },
    ],
    ophthalmology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'ophthalmology', label: 'Ophthalmology', icon: Eye },
      { id: 'jama-ophthalmology', label: 'JAMA Ophthalmology', icon: Eye },
      { id: 'retina', label: 'Retina', icon: Eye },
      { id: 'cornea', label: 'Cornea', icon: Eye },
      { id: 'iovs', label: 'Investigative Ophthalmology & Visual Science', icon: Eye },
      { id: 'eye', label: 'Eye', icon: Eye },
    ],
    surgery: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'annals-surgery', label: 'Annals of Surgery', icon: Scissors },
      { id: 'jama-surgery', label: 'JAMA Surgery', icon: Scissors },
      { id: 'surgery', label: 'Surgery', icon: Scissors },
      { id: 'world-j-surgery', label: 'World Journal of Surgery', icon: Scissors },
      { id: 'jacs', label: 'Journal of the American College of Surgeons', icon: Scissors },
      { id: 'surgical-endoscopy', label: 'Surgical Endoscopy', icon: Scissors },
    ],
    oncology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'cancer-cell', label: 'Cancer Cell', icon: Zap },
      { id: 'nature-cancer', label: 'Nature Cancer', icon: Zap },
      { id: 'jco', label: 'Journal of Clinical Oncology', icon: Zap },
      { id: 'lancet-oncology', label: 'Lancet Oncology', icon: Zap },
      { id: 'jama-oncology', label: 'JAMA Oncology', icon: Zap },
      { id: 'cancer-research', label: 'Cancer Research', icon: Zap },
      { id: 'cancer-discovery', label: 'Cancer Discovery', icon: Zap },
      { id: 'nature-reviews-cancer', label: 'Nature Reviews Cancer', icon: Zap },
      { id: 'clinical-cancer-research', label: 'Clinical Cancer Research', icon: Zap },
    ],
    infectious: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'cid', label: 'Clinical Infectious Diseases', icon: Shield },
      { id: 'jid', label: 'Journal of Infectious Diseases', icon: Shield },
      { id: 'lancet-infectious', label: 'Lancet Infectious Diseases', icon: Shield },
      { id: 'nature-medicine', label: 'Nature Medicine', icon: Microscope },
      { id: 'antimicrobial', label: 'Antimicrobial Agents', icon: Shield },
      { id: 'plos-pathogens', label: 'PLoS Pathogens', icon: Shield },
      { id: 'emerging-infectious', label: 'Emerging Infectious Diseases', icon: Shield },
    ],
    orthopedics: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'jbjs', label: 'Journal of Bone & Joint Surgery', icon: Bone },
      { id: 'orthopedics', label: 'Orthopedics', icon: Bone },
      { id: 'spine', label: 'Spine', icon: Bone },
      { id: 'jama-orthopedics', label: 'JAMA Orthopedics', icon: Bone },
      { id: 'acta-orthop', label: 'Acta Orthopaedica', icon: Bone },
      { id: 'knee-surgery', label: 'Knee Surgery, Sports Traumatology, Arthroscopy', icon: Bone },
    ],
    psychiatry: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'ajp', label: 'American Journal of Psychiatry', icon: Brain },
      { id: 'jama-psychiatry', label: 'JAMA Psychiatry', icon: Brain },
      { id: 'lancet-psychiatry', label: 'Lancet Psychiatry', icon: Brain },
      { id: 'nature-medicine', label: 'Nature Medicine', icon: Microscope },
      { id: 'molecular-psychiatry', label: 'Molecular Psychiatry', icon: Brain },
      { id: 'arch-psychiatry', label: 'Archives of General Psychiatry', icon: Brain },
      { id: 'biological-psychiatry', label: 'Biological Psychiatry', icon: Brain },
    ],
    radiology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'radiology', label: 'Radiology', icon: Waves },
      { id: 'jama-radiology', label: 'JAMA Radiology', icon: Waves },
      { id: 'ajr', label: 'American Journal of Roentgenology', icon: Waves },
      { id: 'nature-medicine', label: 'Nature Medicine', icon: Microscope },
      { id: 'european-radiology', label: 'European Radiology', icon: Waves },
      { id: 'radiographics', label: 'RadioGraphics', icon: Waves },
    ],
    anesthesiology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'anesthesiology', label: 'Anesthesiology', icon: Activity },
      { id: 'anesthesia-analgesia', label: 'Anesthesia & Analgesia', icon: Activity },
      { id: 'british-j-anaesthesia', label: 'British Journal of Anaesthesia', icon: Activity },
      { id: 'european-j-anaesthesia', label: 'European Journal of Anaesthesiology', icon: Activity },
    ],
    pathology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'ajsp', label: 'American Journal of Surgical Pathology', icon: Microscope },
      { id: 'modern-pathology', label: 'Modern Pathology', icon: Microscope },
      { id: 'histopathology', label: 'Histopathology', icon: Microscope },
      { id: 'jcp', label: 'Journal of Clinical Pathology', icon: Microscope },
    ],
    urology: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'jama-urology', label: 'JAMA Urology', icon: Waves },
      { id: 'european-urology', label: 'European Urology', icon: Waves },
      { id: 'juro', label: 'Journal of Urology', icon: Waves },
      { id: 'urology', label: 'Urology', icon: Waves },
    ],
    obstetrics: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'obstet-gynecol', label: 'Obstetrics & Gynecology', icon: Baby },
      { id: 'ajog', label: 'American Journal of Obstetrics and Gynecology', icon: Baby },
      { id: 'bjog', label: 'BJOG: An International Journal of Obstetrics & Gynaecology', icon: Baby },
      { id: 'jama-obstet', label: 'JAMA Obstetrics & Gynecology', icon: Baby },
    ],
    ent: [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'jama-otolaryngology', label: 'JAMA Otolaryngology–Head & Neck Surgery', icon: Activity },
      { id: 'laryngoscope', label: 'The Laryngoscope', icon: Activity },
      { id: 'otolaryngology', label: 'Otolaryngology–Head and Neck Surgery', icon: Activity },
      { id: 'rhinology', label: 'Rhinology', icon: Activity },
    ],
    'plastic-surgery': [
      { id: 'all', label: '全ての雑誌', icon: Filter },
      { id: 'nejm', label: 'NEJM', icon: Stethoscope },
      { id: 'lancet', label: 'The Lancet', icon: FileText },
      { id: 'jama', label: 'JAMA', icon: BookOpen },
      { id: 'bmj', label: 'BMJ', icon: Heart },
      { id: 'annals-internal', label: 'Annals of Internal Medicine', icon: Stethoscope },
      { id: 'plastic-reconstructive', label: 'Plastic and Reconstructive Surgery', icon: Scissors },
      { id: 'aesthetic-surgery', label: 'Aesthetic Surgery Journal', icon: Scissors },
      { id: 'jpras', label: 'Journal of Plastic, Reconstructive & Aesthetic Surgery', icon: Scissors },
      { id: 'annals-plastic', label: 'Annals of Plastic Surgery', icon: Scissors },
    ],
  };

  const currentJournals = journalsBySpecialty[selectedSpecialty as keyof typeof journalsBySpecialty] || journalsBySpecialty.all;

  const handleJournalToggle = (journalId: string) => {
    if (journalId === 'all') {
      onJournalChange(['all']);
    } else {
      if (selectedJournals.includes('all')) {
        // 「全て」から個別雑誌に切り替え
        onJournalChange([journalId]);
      } else {
        if (selectedJournals.includes(journalId)) {
          // 雑誌を選択解除
          const newSelection = selectedJournals.filter(id => id !== journalId);
          if (newSelection.length === 0) {
            onJournalChange(['all']);
          } else {
            onJournalChange(newSelection);
          }
        } else {
          // 雑誌を追加選択
          onJournalChange([...selectedJournals, journalId]);
        }
      }
    }
  };

  return (
    <div className="w-64 bg-white/5 backdrop-blur-xl border-r border-white/10 h-screen overflow-y-auto shadow-2xl">
      <div className="p-6">
        <nav className="space-y-2">
          {mainNavigation.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                  activeTab === item.id
                    ? 'bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-white border-r-2 border-blue-400 shadow-lg backdrop-blur-sm'
                    : 'text-white/80 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
      
      <div className="border-t border-gray-200">
        <button
          onClick={() => setIsSpecialtyExpanded(!isSpecialtyExpanded)}
          className="w-full flex items-center justify-between px-6 py-4 text-left hover:bg-white/10 transition-all duration-300 group"
        >
          <h3 className="text-sm font-semibold text-white">専門分野</h3>
          <div className="flex items-center space-x-2">
            <span className="text-xs text-blue-200 bg-blue-500/20 px-2 py-1 rounded-full backdrop-blur-sm">
              {specialties.length - 1}分野
            </span>
            {isSpecialtyExpanded ? (
              <ChevronDown className="h-4 w-4 text-white/60 group-hover:text-white transition-colors" />
            ) : (
              <ChevronRight className="h-4 w-4 text-white/60 group-hover:text-white transition-colors" />
            )}
          </div>
        </button>
        
        {isSpecialtyExpanded && (
          <div className="px-6 pb-4 space-y-1 max-h-64 overflow-y-auto">
            {specialties.map((specialty) => {
              const Icon = specialty.icon;
              return (
                <button
                  key={specialty.id}
                  onClick={() => {
                    onSpecialtyChange(specialty.id);
                    // 専門分野が変更されたら雑誌選択をリセット
                    onJournalChange(['all']);
                  }}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    selectedSpecialty === specialty.id
                      ? 'bg-gradient-to-r from-teal-500/20 to-cyan-500/20 text-white border border-teal-400/30 shadow-lg backdrop-blur-sm'
                      : 'text-white/70 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="text-sm">{specialty.label}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
      
      <div className="border-t border-gray-200">
        <button
          onClick={() => setIsJournalExpanded(!isJournalExpanded)}
          className="w-full flex items-center justify-between px-6 py-4 text-left hover:bg-white/10 transition-all duration-300 group"
        >
          <h3 className="text-sm font-semibold text-white">
            {selectedSpecialty === 'all' ? '主要雑誌' : `${specialties.find(s => s.id === selectedSpecialty)?.label}の主要雑誌`}
          </h3>
          <div className="flex items-center space-x-2">
            {selectedSpecialty !== 'all' && (
              <span className="text-xs text-purple-200 bg-purple-500/20 px-2 py-1 rounded-full backdrop-blur-sm">
                {selectedJournals.includes('all') ? currentJournals.length - 1 : selectedJournals.filter(id => id !== 'all').length}/{currentJournals.length - 1}誌
              </span>
            )}
            {isJournalExpanded ? (
              <ChevronDown className="h-4 w-4 text-white/60 group-hover:text-white transition-colors" />
            ) : (
              <ChevronRight className="h-4 w-4 text-white/60 group-hover:text-white transition-colors" />
            )}
          </div>
        </button>
        
        {isJournalExpanded && (
          <div className="px-6 pb-4 space-y-2 max-h-80 overflow-y-auto">
            {currentJournals.map((journal) => {
              const Icon = journal.icon;
              const isChecked = selectedJournals.includes(journal.id);
              
              return (
                <label
                  key={journal.id}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                    isChecked
                      ? 'bg-gradient-to-r from-indigo-500/20 to-purple-500/20 text-white border border-indigo-400/30 shadow-lg backdrop-blur-sm'
                      : 'text-white/70 hover:bg-white/10 hover:text-white border border-transparent'
                  } ${journal.id === 'all' ? 'border-b border-white/20 mb-1' : ''}`}
                >
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={() => {
                      handleJournalToggle(journal.id);
                    }}
                    className="h-4 w-4 text-indigo-400 focus:ring-indigo-400/50 border-white/30 rounded bg-white/10 backdrop-blur-sm"
                  />
                  <Icon className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm truncate">{journal.label}</span>
                  {journal.id !== 'all' && (
                    <span className="ml-auto text-xs text-white/50">
                      {journal.id === 'nejm' && 'IF: 176.1'}
                      {journal.id === 'lancet' && 'IF: 168.9'}
                      {journal.id === 'jama' && 'IF: 120.7'}
                      {journal.id === 'bmj' && 'IF: 105.7'}
                      {journal.id === 'nature-medicine' && 'IF: 87.2'}
                    </span>
                  )}
                </label>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;