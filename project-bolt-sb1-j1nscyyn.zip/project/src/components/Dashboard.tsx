import React, { useState } from 'react';
import NEJMSection from './NEJMSection';
import LancetSection from './LancetSection';
import { 
  BookOpen, 
  TrendingUp, 
  Star, 
  Download,
  Calendar,
  Users,
  Activity,
  Eye,
  ExternalLink,
  Play,
  Clock,
  ChevronRight
} from 'lucide-react';

interface DashboardProps {
  selectedJournals: string[];
  sortBy: string;
  filterBy: string;
  onSortChange: (sort: string) => void;
  onFilterChange: (filter: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  selectedJournals, 
  sortBy, 
  filterBy, 
  onSortChange, 
  onFilterChange 
}) => {
  const [selectedArticle, setSelectedArticle] = useState<any>(null);

  const stats = [
    { label: '今日の新着論文', value: '24', icon: BookOpen, color: 'bg-blue-500' },
    { label: 'お気に入り', value: '156', icon: Star, color: 'bg-yellow-500' },
    { label: '今月の読了数', value: '89', icon: Eye, color: 'bg-green-500' },
    { label: 'エクスポート数', value: '12', icon: Download, color: 'bg-purple-500' },
  ];

  const recentActivity = [
    { action: 'Nature Medicine の新着論文をチェック', time: '5分前', type: 'read' },
    { action: '心疾患に関する論文をお気に入りに追加', time: '1時間前', type: 'favorite' },
    { action: 'COVID-19治療法の要約をPDF出力', time: '2時間前', type: 'export' },
    { action: 'NEJM の論文トレンドを分析', time: '3時間前', type: 'analysis' },
  ];

  const featuredJournals = [
    {
      id: 'nature-medicine',
      name: 'Nature Medicine',
      url: 'https://www.nature.com/nm/',
      logo: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      articles: 67,
      trend: '+12%',
      impactFactor: '87.241',
      description: '医学・生物医学分野の最高峰ジャーナル',
      latestArticles: [
        {
          id: '1',
          title: 'Revolutionary CRISPR-based gene therapy shows 95% success rate in treating inherited blindness',
          thumbnail: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '12分',
          publishDate: '2024-12-19',
          summary: '遺伝性失明に対する革新的なCRISPR遺伝子治療が臨床試験で驚異的な成功を収めました。レーバー先天性黒内障患者18名中17名で視力の大幅な改善が確認され、従来不可能とされた遺伝性眼疾患の根本治療への道筋が示されました。',
          evidenceLevel: 'A'
        },
        {
          id: '2',
          title: 'AI-powered drug discovery identifies potential COVID-19 variant-resistant therapeutics',
          thumbnail: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '15分',
          publishDate: '2024-12-18',
          summary: 'AI創薬プラットフォームを用いて、COVID-19の新変異株に対しても有効性を維持する次世代治療薬候補が特定されました。機械学習アルゴリズムにより、従来の薬剤開発期間を80%短縮し、パンデミック対応の新たなパラダイムを提示しています。',
          evidenceLevel: 'A'
        },
        {
          id: '3',
          title: 'Personalized cancer vaccines show 89% efficacy in preventing metastasis',
          thumbnail: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '18分',
          publishDate: '2024-12-17',
          summary: '患者固有の腫瘍抗原を標的とした個別化がんワクチンが、転移予防において89%の有効性を示しました。mRNAワクチン技術を応用したこの治療法は、術後の再発リスクを大幅に低減し、精密医療の新たな可能性を開拓しています。',
          evidenceLevel: 'A'
        }
      ]
    },
    {
      id: 'nejm',
      name: 'New England Journal of Medicine',
      url: 'https://www.nejm.org/',
      logo: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      articles: 52,
      trend: '+15%',
      impactFactor: '176.079',
      description: '世界最高権威の総合医学雑誌',
      latestArticles: [
        {
          id: '4',
          title: 'Groundbreaking heart transplant using genetically modified pig organs shows success',
          thumbnail: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '20分',
          publishDate: '2024-12-19',
          summary: '遺伝子改変豚の心臓を用いた異種移植手術が成功し、患者は術後6ヶ月間良好な経過を示しています。臓器不足問題の解決策として期待される異種移植技術の安全性と有効性が実証され、移植医療の新時代の幕開けを告げています。',
          evidenceLevel: 'A'
        },
        {
          id: '5',
          title: 'Novel Alzheimer\'s drug shows 78% cognitive decline reduction in phase III trial',
          thumbnail: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '16分',
          publishDate: '2024-12-18',
          summary: 'アルツハイマー病の新規治療薬が第III相臨床試験で認知機能低下を78%抑制する画期的な結果を示しました。アミロイドβとタウ蛋白の両方を標的とするデュアルメカニズムにより、従来薬を大幅に上回る治療効果を実現しています。',
          evidenceLevel: 'A'
        },
        {
          id: '6',
          title: 'Minimally invasive robotic surgery reduces complications by 65%',
          thumbnail: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '14分',
          publishDate: '2024-12-17',
          summary: '最新のロボット支援手術システムが、従来の開腹手術と比較して合併症を65%減少させることが大規模多施設研究で確認されました。AI画像解析と精密制御技術の融合により、外科手術の安全性と精度が飛躍的に向上しています。',
          evidenceLevel: 'A'
        }
      ]
    },
    {
      id: 'lancet',
      name: 'The Lancet',
      url: 'https://www.thelancet.com/',
      logo: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      articles: 61,
      trend: '+18%',
      impactFactor: '168.9',
      description: '英国発の権威ある国際医学雑誌',
      latestArticles: [
        {
          id: '7',
          title: 'Universal malaria vaccine achieves 95% efficacy in African field trials',
          thumbnail: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '22分',
          publishDate: '2024-12-19',
          summary: 'アフリカ5カ国での大規模フィールド試験において、新開発のユニバーサルマラリアワクチンが95%の予防効果を示しました。年間60万人の命を奪うマラリアの根絶に向けた画期的な進展として、WHO承認への道筋が開かれました。',
          evidenceLevel: 'A'
        },
        {
          id: '8',
          title: 'Breakthrough stem cell therapy restores spinal cord function in paralyzed patients',
          thumbnail: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '19分',
          publishDate: '2024-12-18',
          summary: '脊髄損傷による完全麻痺患者に対する幹細胞治療が、運動機能の部分的回復を実現しました。iPS細胞由来の神経前駆細胞移植により、損傷部位での神経再生が確認され、脊髄損傷治療の新たな希望となっています。',
          evidenceLevel: 'A'
        },
        {
          id: '9',
          title: 'Digital therapeutics app reduces depression symptoms by 72% in randomized trial',
          thumbnail: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '13分',
          publishDate: '2024-12-17',
          summary: 'AI搭載のデジタル治療アプリが、うつ病症状を72%改善する効果を無作為化比較試験で実証しました。認知行動療法とパーソナライズされた介入を組み合わせたこのアプリは、メンタルヘルス治療のアクセシビリティを革新的に向上させています。',
          evidenceLevel: 'A'
        }
      ]
    },
    {
      id: 'jama',
      name: 'Journal of the American Medical Association',
      url: 'https://jamanetwork.com/',
      logo: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      articles: 48,
      trend: '+11%',
      impactFactor: '120.7',
      description: '米国医師会発行の権威ある総合医学雑誌',
      latestArticles: [
        {
          id: '10',
          title: 'Telemedicine reduces healthcare costs by 40% while maintaining quality outcomes',
          thumbnail: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '11分',
          publishDate: '2024-12-19',
          summary: '遠隔医療システムの大規模導入により、医療費を40%削減しながら治療品質を維持できることが実証されました。AI診断支援とリモートモニタリング技術の組み合わせにより、効率的で質の高い医療提供が実現されています。',
          evidenceLevel: 'A'
        },
        {
          id: '11',
          title: 'Preventive lifestyle intervention reduces type 2 diabetes risk by 85%',
          thumbnail: 'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '17分',
          publishDate: '2024-12-18',
          summary: '包括的な生活習慣介入プログラムが、2型糖尿病発症リスクを85%減少させる効果を示しました。栄養指導、運動療法、行動変容支援を統合したアプローチにより、予防医学の新たな標準が確立されました。',
          evidenceLevel: 'A'
        }
      ]
    },
    {
      id: 'bmj',
      name: 'British Medical Journal',
      url: 'https://www.bmj.com/',
      logo: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop',
      articles: 39,
      trend: '+9%',
      impactFactor: '105.7',
      description: '英国医師会発行の国際的医学雑誌',
      latestArticles: [
        {
          id: '12',
          title: 'Population-based screening program reduces cancer mortality by 35%',
          thumbnail: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
          duration: '16分',
          publishDate: '2024-12-19',
          summary: '国民規模のがんスクリーニングプログラムが、がん死亡率を35%減少させる効果を示しました。AI画像診断と液体生検技術を組み合わせた早期発見システムにより、治療可能な段階でのがん発見率が大幅に向上しています。',
          evidenceLevel: 'A'
        }
      ]
    }
  ];

  const filteredJournals = selectedJournals.includes('all') 
    ? featuredJournals 
    : featuredJournals.filter(journal => selectedJournals.includes(journal.id));

  // NEJMが選択されている場合は専用セクションを表示
  if (selectedJournals.includes('nejm') && selectedJournals.length === 1) {
    return (
      <div className="p-6 space-y-6 relative">
        <NEJMSection />
      </div>
    );
  }

  // The Lancetが選択されている場合は専用セクションを表示
  if (selectedJournals.includes('lancet') && selectedJournals.length === 1) {
    return (
      <div className="p-6 space-y-6 relative">
        <LancetSection />
      </div>
    );
  }

  const getEvidenceBadgeColor = (level: string) => {
    switch (level) {
      case 'A': return 'bg-green-100 text-green-800';
      case 'B': return 'bg-yellow-100 text-yellow-800';
      case 'C': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6 space-y-6 relative">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-white via-blue-200 to-purple-200 bg-clip-text text-transparent">ダッシュボード</h2>
        <div className="flex items-center space-x-2 text-sm text-white/70">
          <Calendar className="h-4 w-4" />
          <span>最終更新: 2024年12月19日 14:30</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 group">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-white/70 group-hover:text-white transition-colors">{stat.label}</p>
                  <p className="text-3xl font-bold text-white">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-4 rounded-2xl shadow-lg transform group-hover:scale-110 transition-all duration-300`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Featured Journals with YouTube-style Layout */}
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <h3 className="text-2xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
            {selectedJournals.includes('all') ? '注目の医学雑誌' : 
             filteredJournals.length === 1 ? `${filteredJournals[0]?.name}` : 
             `選択された雑誌 (${filteredJournals.length}誌)`}
          </h3>
          {!selectedJournals.includes('all') && filteredJournals.length > 0 && (
            <span className="text-sm text-white/70 bg-white/10 px-3 py-1 rounded-full backdrop-blur-sm">
              {filteredJournals.reduce((total, journal) => total + journal.articles, 0)} 論文
            </span>
          )}
        </div>
        
        {filteredJournals.map((journal) => (
          <div key={journal.id} className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/20 overflow-hidden hover:bg-white/20 transition-all duration-500 transform hover:scale-[1.02]">
            {/* Journal Header */}
            <div className="p-6 border-b border-white/20 bg-gradient-to-r from-transparent to-white/5">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <img 
                    src={journal.logo} 
                    alt={journal.name}
                    className="w-16 h-16 rounded-2xl object-cover shadow-lg ring-2 ring-white/20"
                  />
                  <div>
                    <h4 className="text-xl font-bold text-white">{journal.name}</h4>
                    <div className="flex items-center space-x-4 text-sm text-white/70">
                      <span>{journal.articles} 論文</span>
                      <div className="flex items-center space-x-1">
                        <TrendingUp className="h-4 w-4 text-green-500" />
                        <span className="text-green-400 font-medium">{journal.trend}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <a 
                  href={journal.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  <ExternalLink className="h-4 w-4" />
                  <span>公式サイト</span>
                </a>
              </div>
            </div>

            {/* YouTube-style Article Grid */}
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {journal.latestArticles.map((article) => (
                  <div 
                    key={article.id}
                    className="cursor-pointer group transform hover:scale-105 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-400 rounded-2xl bg-white/5 hover:bg-white/10 p-2"
                    tabIndex={0}
                    onClick={() => {
                      console.log('🔍 Article clicked:', article.title);
                      console.log('📄 Article data:', article);
                      setSelectedArticle({
                        ...article,
                        journal: journal.name,
                        journalId: journal.id,
                        impactFactor: journal.impactFactor,
                        fullSummary: article.summary,
                        keyPoints: [
                          '革新的な治療法の開発',
                          '大規模臨床試験による検証',
                          '高い安全性プロファイル',
                          '将来の医療への応用可能性'
                        ],
                        clinicalSignificance: 'この研究は現在の医療実践に重要な影響を与え、患者の治療成績向上に寄与する可能性があります。',
                        methodology: '多施設共同無作為化二重盲検プラセボ対照試験',
                        sampleSize: '1,000名以上の患者を対象',
                        followUp: '平均追跡期間24ヶ月',
                        primaryEndpoint: '主要評価項目において統計学的有意差を確認',
                        doi: `10.1056/NEJMoa${Date.now()}`,
                        authors: ['田中太郎', '山田花子', 'Smith JA', 'Johnson MB', 'Brown CL'],
                        keywords: ['革新的治療', '臨床試験', '安全性', '有効性', '医療技術']
                      });
                      console.log('✅ Modal should open now');
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        console.log('⌨️ Keyboard interaction:', e.key);
                        setSelectedArticle({
                          ...article,
                          journal: journal.name,
                          journalId: journal.id,
                          impactFactor: journal.impactFactor,
                          fullSummary: article.summary,
                          keyPoints: [
                            '革新的な治療法の開発',
                            '大規模臨床試験による検証',
                            '高い安全性プロファイル',
                            '将来の医療への応用可能性'
                          ],
                          clinicalSignificance: 'この研究は現在の医療実践に重要な影響を与え、患者の治療成績向上に寄与する可能性があります。',
                          methodology: '多施設共同無作為化二重盲検プラセボ対照試験',
                          sampleSize: '1,000名以上の患者を対象',
                          followUp: '平均追跡期間24ヶ月',
                          primaryEndpoint: '主要評価項目において統計学的有意差を確認',
                          doi: `10.1056/NEJMoa${Date.now()}`,
                          authors: ['田中太郎', '山田花子', 'Smith JA', 'Johnson MB', 'Brown CL'],
                          keywords: ['革新的治療', '臨床試験', '安全性', '有効性', '医療技術']
                        });
                      }
                    }}
                  >
                    <div className="relative">
                      <img 
                        src={article.thumbnail}
                        alt={article.title}
                        className="w-full h-48 object-cover rounded-2xl group-hover:opacity-90 transition-all duration-300 shadow-lg ring-1 ring-white/20 pointer-events-none"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 rounded-2xl flex items-center justify-center">
                        <div className="bg-white/20 backdrop-blur-sm rounded-full p-4 transform scale-75 group-hover:scale-100 transition-all duration-300">
                          <Play className="h-6 w-6 text-white pointer-events-none" />
                        </div>
                      </div>
                      <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-sm text-white text-xs px-3 py-1 rounded-full">
                        {article.duration}
                      </div>
                      <div className="absolute top-3 left-3">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${getEvidenceBadgeColor(article.evidenceLevel)}`}>
                          レベル {article.evidenceLevel}
                        </span>
                      </div>
                    </div>
                    <div className="mt-3">
                      <h5 className="font-semibold text-white line-clamp-2 group-hover:text-blue-300 transition-colors">
                        {article.title}
                      </h5>
                      <div className="flex items-center space-x-2 mt-1 text-sm text-white/60">
                        <Clock className="h-3 w-3" />
                        <span>{article.publishDate}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4">最近のアクティビティ</h3>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full animate-pulse"></div>
                <div className="flex-1">
                  <p className="text-sm text-white/90">{activity.action}</p>
                  <p className="text-xs text-white/60">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4">クイックアクション</h3>
          <div className="space-y-3">
            <button className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-xl hover:from-blue-500/30 hover:to-cyan-500/30 transition-all duration-300 transform hover:scale-105 border border-blue-400/30 backdrop-blur-sm">
              <div className="flex items-center space-x-3">
                <BookOpen className="h-5 w-5 text-blue-300" />
                <div className="text-left">
                  <p className="font-semibold text-white">新着論文をチェック</p>
                  <p className="text-sm text-blue-200">最新の研究成果を確認</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-blue-300" />
            </button>
            
            <button className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl hover:from-green-500/30 hover:to-emerald-500/30 transition-all duration-300 transform hover:scale-105 border border-green-400/30 backdrop-blur-sm">
              <div className="flex items-center space-x-3">
                <TrendingUp className="h-5 w-5 text-green-300" />
                <div className="text-left">
                  <p className="font-semibold text-white">トレンド分析</p>
                  <p className="text-sm text-green-200">研究動向を可視化</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-green-300" />
            </button>
            
            <button className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl hover:from-purple-500/30 hover:to-pink-500/30 transition-all duration-300 transform hover:scale-105 border border-purple-400/30 backdrop-blur-sm">
              <div className="flex items-center space-x-3">
                <Download className="h-5 w-5 text-purple-300" />
                <div className="text-left">
                  <p className="font-semibold text-white">レポート作成</p>
                  <p className="text-sm text-purple-200">要約資料を生成</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-purple-300" />
            </button>
          </div>
        </div>
      </div>

      {/* Article Summary Modal */}
      {selectedArticle && (
        <>
          {console.log('🎭 Rendering modal for:', selectedArticle.title)}
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              console.log('🚪 Closing modal via background click');
              setSelectedArticle(null);
            }
          }}
          onKeyDown={(e) => {
            if (e.key === 'Escape') {
              console.log('🚪 Closing modal via ESC key');
              setSelectedArticle(null);
            }
          }}
          tabIndex={-1}
        >
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl max-w-6xl w-full max-h-[90vh] overflow-y-auto border border-white/20 shadow-2xl transform animate-slideUp">
            <div className="p-6 border-b border-white/20 bg-gradient-to-r from-transparent to-white/5">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getEvidenceBadgeColor(selectedArticle.evidenceLevel)}`}>
                    エビデンスレベル {selectedArticle.evidenceLevel}
                  </span>
                  <span className="px-2 py-1 text-xs font-medium bg-blue-500/20 text-blue-300 rounded-full border border-blue-400/30">
                    {selectedArticle.journal}
                  </span>
                  {selectedArticle.impactFactor && (
                    <span className="px-2 py-1 text-xs font-medium bg-purple-500/20 text-purple-300 rounded-full border border-purple-400/30">
                      IF: {selectedArticle.impactFactor}
                    </span>
                  )}
                  <span className="text-sm text-white/70">{selectedArticle.publishDate}</span>
                </div>
                <button 
                  onClick={() => {
                    console.log('🚪 Closing modal via close button');
                    setSelectedArticle(null);
                  }}
                  className="text-white/60 hover:text-white text-2xl transform hover:scale-110 transition-all duration-300 p-2 rounded-full hover:bg-white/10"
                  aria-label="モーダルを閉じる"
                >
                  ✕
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Main Content */}
                <div className="lg:col-span-2">
                  <h2 className="text-3xl font-bold text-white mb-6">{selectedArticle.title}</h2>
                  
                  {selectedArticle.thumbnail && (
                    <img 
                      src={selectedArticle.thumbnail}
                      alt={selectedArticle.title}
                      className="w-full h-64 object-cover rounded-2xl mb-6 shadow-lg ring-1 ring-white/20"
                    />
                  )}
                  
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-4">研究概要</h3>
                      <p className="text-white/90 leading-relaxed text-lg">{selectedArticle.fullSummary || selectedArticle.summary}</p>
                    </div>
                    
                    {selectedArticle.keyPoints && (
                      <div>
                        <h3 className="text-2xl font-bold text-white mb-4">研究のポイント</h3>
                        <ul className="space-y-2">
                          {selectedArticle.keyPoints.map((point, index) => (
                            <li key={index} className="flex items-start space-x-3">
                              <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0"></div>
                              <span className="text-white/90">{point}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    
                    {selectedArticle.methodology && (
                      <div>
                        <h3 className="text-2xl font-bold text-white mb-4">研究方法</h3>
                        <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-white/60">研究デザイン:</span>
                              <p className="text-white/90">{selectedArticle.methodology}</p>
                            </div>
                            <div>
                              <span className="text-white/60">対象患者:</span>
                              <p className="text-white/90">{selectedArticle.sampleSize}</p>
                            </div>
                            <div>
                              <span className="text-white/60">追跡期間:</span>
                              <p className="text-white/90">{selectedArticle.followUp}</p>
                            </div>
                            <div>
                              <span className="text-white/60">主要結果:</span>
                              <p className="text-white/90">{selectedArticle.primaryEndpoint}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {selectedArticle.clinicalSignificance && (
                      <div>
                        <h3 className="text-2xl font-bold text-white mb-4">臨床的意義</h3>
                        <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-xl p-4 border border-green-400/20">
                          <p className="text-white/90 leading-relaxed">{selectedArticle.clinicalSignificance}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Sidebar */}
                <div className="space-y-6">
                  {/* Article Info */}
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                    <h4 className="text-lg font-bold text-white mb-4">論文情報</h4>
                    <div className="space-y-3 text-sm">
                      <div>
                        <span className="text-white/60">著者: </span>
                        <span className="text-white">{selectedArticle.authors?.join(', ') || '詳細は原文参照'}</span>
                      </div>
                      <div>
                        <span className="text-white/60">雑誌: </span>
                        <span className="text-white">{selectedArticle.journal}</span>
                      </div>
                      <div>
                        <span className="text-white/60">発表日: </span>
                        <span className="text-white">{selectedArticle.publishDate}</span>
                      </div>
                      <div>
                        <span className="text-white/60">読了時間: </span>
                        <span className="text-white">{selectedArticle.duration}</span>
                      </div>
                      {selectedArticle.doi && (
                        <div>
                          <span className="text-white/60">DOI: </span>
                          <a 
                            href={`https://doi.org/${selectedArticle.doi}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-300 hover:text-blue-200 transition-colors break-all"
                          >
                            {selectedArticle.doi}
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Keywords */}
                  {selectedArticle.keywords && (
                    <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                      <h4 className="text-lg font-bold text-white mb-4">キーワード</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedArticle.keywords.map((keyword, index) => (
                          <span 
                            key={index}
                            className="px-3 py-1 bg-white/10 text-white/80 rounded-full text-sm border border-white/20"
                          >
                            {keyword}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Actions */}
                  <div className="space-y-3">
                    {selectedArticle.doi && (
                      <a
                        href={`https://doi.org/${selectedArticle.doi}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg font-semibold"
                      >
                        <ExternalLink className="h-4 w-4" />
                        <span>原文を読む</span>
                      </a>
                    )}
                    <button 
                      onClick={() => {
                        console.log('お気に入りに追加:', selectedArticle.title);
                        // お気に入り機能の実装
                      }}
                      className="w-full px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 font-semibold flex items-center justify-center space-x-2"
                    >
                      <Star className="h-4 w-4" />
                      <span>お気に入りに追加</span>
                    </button>
                    <button 
                      onClick={() => {
                        console.log('PDF出力:', selectedArticle.title);
                        // PDF出力機能の実装
                      }}
                      className="w-full px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 font-semibold flex items-center justify-center space-x-2"
                    >
                      <Download className="h-4 w-4" />
                      <span>PDF出力</span>
                    </button>
                    <button 
                      onClick={() => {
                        console.log('音声再生:', selectedArticle.title);
                        // 音声再生機能の実装
                      }}
                      className="w-full px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 font-semibold flex items-center justify-center space-x-2"
                    >
                      <Play className="h-4 w-4" />
                      <span>音声で聞く</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        </>
      )}
    </div>
  );
};

export default Dashboard;