import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Settings, 
  Download, 
  Volume2, 
  Send,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  BookOpen,
  Users,
  Clock,
  Award,
  Filter,
  FileText,
  Headphones,
  Share2
} from 'lucide-react';
import { 
  fetchMedicalLiteratureData, 
  MedicalArticleData, 
  SPECIALTY_JOURNALS, 
  CORE_JOURNALS,
  WeeklyUpdateConfig,
  AISummaryConfig,
  OutputConfig,
  generateAISummary,
  postToSlack,
  generatePDF,
  generateMarkdown,
  generateAudio
} from '../services/medical-journals-api';

const MedicalLiteratureSystem: React.FC = () => {
  const [articles, setArticles] = useState<MedicalArticleData[]>([]);
  const [selectedSpecialties, setSelectedSpecialties] = useState<string[]>(['内科']);
  const [customJournals, setCustomJournals] = useState<string[]>([]);
  const [selectedJournals, setSelectedJournals] = useState<string[]>(['all']);
  const [sortBy, setSortBy] = useState<'date' | 'journal' | 'evidence' | 'citations'>('date');
  const [filterBy, setFilterBy] = useState<'all' | 'favorites' | 'recent'>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'articles' | 'settings' | 'export'>('articles');
  // PDF出力設定
  const [pdfSettings, setPdfSettings] = useState({
    fontSize: 12,
    fontFamily: 'NotoSansJP',
    encoding: 'UTF-8',
    paperSize: 'A4',
    margin: 20,
    includeImages: true,
    includeReferences: true
  });

  
  // 設定状態
  const [weeklyConfig, setWeeklyConfig] = useState<WeeklyUpdateConfig>({
    enabled: true,
    dayOfWeek: 1, // 月曜日
    timeOfDay: '09:00',
    selectedSpecialties: ['内科'],
    customJournals: [],
    slackWebhookUrl: '',
    slackChannel: '#medical-literature'
  });

  const [aiConfig, setAiConfig] = useState<AISummaryConfig>({
    enabled: true,
    targetLength: 600,
    includeTranslation: true,
    preserveTechnicalTerms: true,
    summaryStyle: 'clinical'
  });

  const [outputConfig, setOutputConfig] = useState<OutputConfig>({
    enablePDF: true,
    enableMarkdown: true,
    enableAudio: true,
    obsidianCompatible: true,
    audioLanguage: 'ja-JP',
    audioSpeed: 1.0
  });

  // データ取得関数
  const loadArticles = async (forceUpdate: boolean = false) => {
    setIsLoading(true);
    try {
      const updateType = forceUpdate ? '強制更新（過去7日間）' : '増分更新（最終更新日以降）';
      console.log(`🔄 医学文献データ取得開始... (${updateType})`);
      
      const data = await fetchMedicalLiteratureData(
        selectedSpecialties,
        customJournals,
        lastUpdated || undefined,
        forceUpdate
      );
      
      if (forceUpdate || !lastUpdated) {
        // 強制更新または初回取得の場合は全て置き換え
        console.log(`📊 論文データを全て置き換え: ${data.length}件`);
        setArticles(data);
      } else {
        // 増分更新の場合は新しい記事のみ追加
        setArticles(prev => {
          const existingIds = new Set(prev.map(a => a.id));
          const newArticles = data.filter(a => !existingIds.has(a.id));
          const updatedArticles = [...newArticles, ...prev].sort((a, b) => 
            new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime()
          );
          console.log(`📊 新規論文: ${newArticles.length}件, 既存論文: ${prev.length}件, 合計: ${updatedArticles.length}件`);
          return updatedArticles;
        });
        
        // 新しい記事が見つからない場合の通知
        const existingIds = new Set(articles.map(a => a.id));
        const newCount = data.filter(a => !existingIds.has(a.id)).length;
        if (newCount === 0) {
          console.log('ℹ️ 最終更新日以降の新しい論文は見つかりませんでした');
        }
      }
      
      setLastUpdated(new Date().toISOString());
      console.log(`✅ データ取得完了: ${data.length}件`);
    } catch (error) {
      console.error('❌ データ取得エラー:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // 初回データ取得
  useEffect(() => {
    loadArticles(true); // 初回は強制更新
  }, [selectedSpecialties, customJournals]);

  // 診療科選択ハンドラー
  const handleSpecialtyChange = (specialty: string, checked: boolean) => {
    if (checked) {
      setSelectedSpecialties(prev => [...prev, specialty]);
    } else {
      setSelectedSpecialties(prev => prev.filter(s => s !== specialty));
    }
  };

  // 雑誌選択ハンドラー
  const handleJournalChange = (journal: string, checked: boolean) => {
    if (journal === 'all') {
      setSelectedJournals(['all']);
    } else {
      setSelectedJournals(prev => {
        const newSelection = prev.filter(j => j !== 'all');
        if (checked) {
          return [...newSelection, journal];
        } else {
          const filtered = newSelection.filter(j => j !== journal);
          return filtered.length === 0 ? ['all'] : filtered;
        }
      });
    }
  };

  // 記事フィルタリング・ソート
  const getFilteredAndSortedArticles = () => {
    let filtered = articles;

    // 雑誌フィルタリング
    if (!selectedJournals.includes('all')) {
      filtered = filtered.filter(article => 
        selectedJournals.some(selectedJournal => 
          article.journalName.toLowerCase().includes(selectedJournal.toLowerCase()) ||
          selectedJournal.toLowerCase().includes(article.journalName.toLowerCase())
        )
      );
    }

    // その他のフィルタリング
    if (filterBy === 'recent') {
      const threeDaysAgo = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000);
      filtered = filtered.filter(article => 
        new Date(article.publishDate) >= threeDaysAgo
      );
    }

    // ソート
    const sorted = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'date':
          return new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime();
        case 'journal':
          return a.journalName.localeCompare(b.journalName);
        case 'evidence':
          const evidenceOrder = { 'A': 3, 'B': 2, 'C': 1 };
          return evidenceOrder[b.evidenceLevel] - evidenceOrder[a.evidenceLevel];
        case 'citations':
          return b.citationCount - a.citationCount;
        default:
          return 0;
      }
    });

    return sorted;
  };

  const filteredAndSortedArticles = getFilteredAndSortedArticles();

  // 利用可能な雑誌リストを生成
  const getAvailableJournals = () => {
    const journalCounts = articles.reduce((acc, article) => {
      acc[article.journalName] = (acc[article.journalName] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(journalCounts)
      .sort(([, a], [, b]) => b - a)
      .map(([journal, count]) => ({ journal, count }));
  };

  const availableJournals = getAvailableJournals();
  // AI要約生成
  const handleGenerateAISummary = async (article: MedicalArticleData) => {
    try {
      const summary = await generateAISummary(article, aiConfig);
      // 記事の要約を更新
      setArticles(prev => prev.map(a => 
        a.id === article.id ? { ...a, summaryJapanese: summary } : a
      ));
    } catch (error) {
      console.error('AI要約生成エラー:', error);
    }
  };

  // Slack投稿
  const handleSlackPost = async () => {
    if (!weeklyConfig.slackWebhookUrl) {
      alert('Slack Webhook URLを設定してください');
      return;
    }

    try {
      const success = await postToSlack(
        articles,
        weeklyConfig.slackWebhookUrl,
        weeklyConfig.slackChannel
      );
      
      if (success) {
        alert('Slackに投稿しました！');
      } else {
        alert('Slack投稿に失敗しました');
      }
    } catch (error) {
      console.error('Slack投稿エラー:', error);
      alert('Slack投稿中にエラーが発生しました');
    }
  };

  // PDF出力
  const handlePDFExport = async () => {
    try {
      const pdfUrl = await generatePDF(articles);
      // ダウンロードリンクを作成
      const link = document.createElement('a');
      link.href = pdfUrl;
      link.download = `medical-literature-${new Date().toISOString().split('T')[0]}.pdf`;
      link.click();
    } catch (error) {
      console.error('PDF出力エラー:', error);
      alert('PDF出力中にエラーが発生しました');
    }
  };

  // Markdown出力
  const handleMarkdownExport = async () => {
    try {
      const markdown = await generateMarkdown(articles, outputConfig.obsidianCompatible);
      const blob = new Blob([markdown], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `medical-literature-${new Date().toISOString().split('T')[0]}.md`;
      link.click();
      
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Markdown出力エラー:', error);
      alert('Markdown出力中にエラーが発生しました');
    }
  };

  // 音声生成
  const handleAudioGeneration = async (article: MedicalArticleData) => {
    try {
      const text = article.summaryJapanese || article.summary;
      const audioUrl = await generateAudio(text, outputConfig.audioLanguage, outputConfig.audioSpeed);
      
      // 記事に音声URLを追加
      setArticles(prev => prev.map(a => 
        a.id === article.id ? { ...a, audioUrl } : a
      ));
    } catch (error) {
      console.error('音声生成エラー:', error);
      alert('音声生成中にエラーが発生しました');
    }
  };

  const getEvidenceBadgeColor = (level: string) => {
    switch (level) {
      case 'A': return 'bg-green-500/20 text-green-300 border border-green-400/30';
      case 'B': return 'bg-yellow-500/20 text-yellow-300 border border-yellow-400/30';
      case 'C': return 'bg-red-500/20 text-red-300 border border-red-400/30';
      default: return 'bg-gray-500/20 text-gray-300 border border-gray-400/30';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Background Animation */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-yellow-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative z-10 p-6">
        {/* Header */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-white via-blue-200 to-purple-200 bg-clip-text text-transparent mb-2">
                医学文献自動要約システム
              </h1>
              <p className="text-white/80 text-lg">主要医学雑誌の最新情報を自動収集・要約・配信</p>
            </div>
            
            <div className="flex items-center space-x-4">
              {lastUpdated && (
                <div className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span className="text-sm text-white/80">
                    最終更新: {new Date(lastUpdated).toLocaleString('ja-JP')}
                  </span>
                </div>
              )}
              
              <button
                onClick={() => loadArticles(false)}
                disabled={isLoading}
                className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <RefreshCw className={`h-5 w-5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>増分更新（新着のみ）</span>
              </button>
              
              <button
                onClick={() => loadArticles(true)}
                disabled={isLoading}
                className="flex items-center space-x-2 px-4 py-3 bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-xl hover:from-green-700 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                <span>全更新（過去7日）</span>
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-4 mb-8">
          {[
            { id: 'articles', label: '論文一覧', icon: BookOpen },
            { id: 'settings', label: '設定', icon: Settings },
            { id: 'export', label: 'エクスポート', icon: Download }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-xl transition-all duration-300 transform hover:scale-105 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-blue-500/30 to-purple-500/30 text-white border border-blue-400/50 shadow-lg'
                    : 'bg-white/10 text-white/80 hover:bg-white/20 border border-white/20'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="font-medium">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content */}
        {activeTab === 'articles' && (
          <div className="space-y-6">
            {/* Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white/70">総論文数</p>
                    <p className="text-3xl font-bold text-white">{filteredAndSortedArticles.length}</p>
                    {articles.length !== filteredAndSortedArticles.length && (
                      <p className="text-xs text-white/60">全体: {articles.length}件</p>
                    )}
                  </div>
                  <BookOpen className="h-8 w-8 text-blue-400" />
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white/70">対象雑誌数</p>
                    <p className="text-3xl font-bold text-white">
                      {(() => {
                        const targetJournals = new Set([
                          ...CORE_JOURNALS,
                          ...selectedSpecialties.flatMap(specialty => 
                            SPECIALTY_JOURNALS[specialty as keyof typeof SPECIALTY_JOURNALS] || []
                          )
                        ]);
                        return targetJournals.size;
                      })()}
                    </p>
                  </div>
                  <Users className="h-8 w-8 text-green-400" />
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white/70">選択診療科</p>
                    <p className="text-3xl font-bold text-white">{selectedSpecialties.length}</p>
                  </div>
                  <Award className="h-8 w-8 text-purple-400" />
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white/70">エビデンスレベルA</p>
                    <p className="text-3xl font-bold text-white">
                      {filteredAndSortedArticles.filter(a => a.evidenceLevel === 'A').length}
                    </p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-green-400" />
                </div>
              </div>
            </div>

            {/* Journal Selection and Sorting Controls */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Journal Filter */}
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
                  <Filter className="h-5 w-5" />
                  <span>雑誌フィルター</span>
                </h3>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  <label className="flex items-center space-x-3 p-3 rounded-xl bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-400/30">
                    <input
                      type="checkbox"
                      checked={selectedJournals.includes('all')}
                      onChange={(e) => handleJournalChange('all', e.target.checked)}
                      className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                    />
                    <div className="flex-1">
                      <span className="text-white font-medium">全ての雑誌</span>
                      <div className="text-xs text-blue-200">
                        {articles.length}件の論文
                      </div>
                    </div>
                  </label>
                  
                  {availableJournals.map(({ journal, count }) => (
                    <label
                      key={journal}
                      className={`flex items-center space-x-3 p-3 rounded-xl transition-all duration-300 cursor-pointer ${
                        selectedJournals.includes(journal) && !selectedJournals.includes('all')
                          ? 'bg-gradient-to-r from-green-500/30 to-teal-500/30 border border-green-400/50 shadow-lg'
                          : 'bg-white/10 hover:bg-white/20 border border-white/20'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={selectedJournals.includes('all') || selectedJournals.includes(journal)}
                        onChange={(e) => handleJournalChange(journal, e.target.checked)}
                        className="h-4 w-4 text-green-400 focus:ring-green-400/50 border-white/30 rounded bg-white/10"
                      />
                      <div className="flex-1">
                        <span className="text-white font-medium text-sm">{journal}</span>
                        <div className="text-xs text-white/60">
                          {count}件の論文
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Sort and Filter Controls */}
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4">ソート・フィルター</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-white/80 mb-2">ソート順</label>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-blue-400/50 focus:border-blue-400/50"
                    >
                      <option value="date">発表日（新しい順）</option>
                      <option value="journal">雑誌名（アルファベット順）</option>
                      <option value="evidence">エビデンスレベル（高い順）</option>
                      <option value="citations">引用数（多い順）</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-white/80 mb-2">フィルター</label>
                    <select
                      value={filterBy}
                      onChange={(e) => setFilterBy(e.target.value as any)}
                      className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-blue-400/50 focus:border-blue-400/50"
                    >
                      <option value="all">全ての論文</option>
                      <option value="recent">最近3日間</option>
                      <option value="favorites">お気に入り</option>
                    </select>
                  </div>
                  
                  <div className="pt-4 border-t border-white/20">
                    <div className="text-sm text-white/70 space-y-1">
                      <p>表示中: <span className="font-bold text-white">{filteredAndSortedArticles.length}</span>件</p>
                      <p>全体: <span className="font-bold text-white">{articles.length}</span>件</p>
                      {selectedJournals.length > 0 && !selectedJournals.includes('all') && (
                        <p>選択雑誌: <span className="font-bold text-green-300">{selectedJournals.length}</span>誌</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Selected Specialties and Journals Display */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Selected Specialties */}
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
                  <Award className="h-5 w-5 text-purple-400" />
                  <span>選択中の診療科 ({selectedSpecialties.length}科)</span>
                </h3>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {selectedSpecialties.length > 0 ? (
                    selectedSpecialties.map((specialty, index) => (
                      <div
                        key={specialty}
                        className="flex items-center justify-between p-3 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-xl border border-purple-400/30"
                      >
                        <span className="text-white font-medium">{specialty}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs text-purple-200 bg-purple-500/20 px-2 py-1 rounded-full">
                            {SPECIALTY_JOURNALS[specialty as keyof typeof SPECIALTY_JOURNALS]?.length || 0}誌
                          </span>
                          <button
                            onClick={() => handleSpecialtyChange(specialty, false)}
                            className="text-white/60 hover:text-white hover:bg-white/10 rounded-full p-1 transition-all duration-300"
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-white/60">
                      <Award className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p>診療科が選択されていません</p>
                      <p className="text-sm">下記から診療科を選択してください</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Target Journals */}
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
                  <BookOpen className="h-5 w-5 text-green-400" />
                  <span>対象雑誌一覧 ({(() => {
                    const targetJournals = new Set([
                      ...CORE_JOURNALS,
                      ...selectedSpecialties.flatMap(specialty => 
                        SPECIALTY_JOURNALS[specialty as keyof typeof SPECIALTY_JOURNALS] || []
                      ),
                      ...customJournals
                    ]);
                    return targetJournals.size;
                  })()}誌)</span>
                </h3>
                <div className="space-y-3 max-h-48 overflow-y-auto">
                  {/* Core Journals */}
                  <div>
                    <h4 className="text-sm font-semibold text-blue-300 mb-2 flex items-center space-x-1">
                      <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                      <span>必須主要雑誌 ({CORE_JOURNALS.length}誌)</span>
                    </h4>
                    <div className="space-y-1">
                      {CORE_JOURNALS.map((journal, index) => (
                        <div
                          key={journal}
                          className="text-sm text-white/80 bg-blue-500/10 px-3 py-2 rounded-lg border border-blue-400/20"
                        >
                          {journal}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Specialty Journals */}
                  {selectedSpecialties.map(specialty => {
                    const specialtyJournals = SPECIALTY_JOURNALS[specialty as keyof typeof SPECIALTY_JOURNALS] || [];
                    if (specialtyJournals.length === 0) return null;
                    
                    return (
                      <div key={specialty}>
                        <h4 className="text-sm font-semibold text-purple-300 mb-2 flex items-center space-x-1">
                          <span className="w-2 h-2 bg-purple-400 rounded-full"></span>
                          <span>{specialty}専門誌 ({specialtyJournals.length}誌)</span>
                        </h4>
                        <div className="space-y-1">
                          {specialtyJournals.map((journal, index) => (
                            <div
                              key={journal}
                              className="text-sm text-white/80 bg-purple-500/10 px-3 py-2 rounded-lg border border-purple-400/20"
                            >
                              {journal}
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}

                  {/* Custom Journals */}
                  {customJournals.length > 0 && (
                    <div>
                      <h4 className="text-sm font-semibold text-green-300 mb-2 flex items-center space-x-1">
                        <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                        <span>カスタム雑誌 ({customJournals.length}誌)</span>
                      </h4>
                      <div className="space-y-1">
                        {customJournals.map((journal, index) => (
                          <div
                            key={journal}
                            className="text-sm text-white/80 bg-green-500/10 px-3 py-2 rounded-lg border border-green-400/20 flex items-center justify-between"
                          >
                            <span>{journal}</span>
                            <button
                              onClick={() => setCustomJournals(prev => prev.filter(j => j !== journal))}
                              className="text-white/60 hover:text-white hover:bg-white/10 rounded-full p-1 transition-all duration-300"
                            >
                              ✕
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedSpecialties.length === 0 && customJournals.length === 0 && (
                    <div className="text-center py-4 text-white/60">
                      <p className="text-sm">診療科を選択すると専門雑誌が表示されます</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Specialty Filter */}
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
                <Filter className="h-5 w-5" />
                <span>診療科選択</span>
              </h3>
              <div className="mb-4 p-3 bg-blue-500/10 rounded-xl border border-blue-400/20">
                <p className="text-sm text-blue-200">
                  <strong>必須主要雑誌</strong>: {CORE_JOURNALS.join(', ')} は常に含まれます
                </p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {Object.keys(SPECIALTY_JOURNALS).map(specialty => (
                  <label
                    key={specialty}
                    className={`flex items-center space-x-2 p-3 rounded-xl transition-all duration-300 cursor-pointer ${
                      selectedSpecialties.includes(specialty)
                        ? 'bg-gradient-to-r from-purple-500/30 to-blue-500/30 border border-purple-400/50 shadow-lg'
                        : 'bg-white/10 hover:bg-white/20 border border-white/20'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={selectedSpecialties.includes(specialty)}
                      onChange={(e) => handleSpecialtyChange(specialty, e.target.checked)}
                      className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                    />
                    <div className="flex-1">
                      <span className="text-sm text-white font-medium">{specialty}</span>
                      <div className="text-xs text-white/60">
                        {SPECIALTY_JOURNALS[specialty as keyof typeof SPECIALTY_JOURNALS]?.length || 0}誌
                      </div>
                    </div>
                  </label>
                ))}
              </div>
              
              {/* Custom Journal Input */}
              <div className="mt-6 p-4 bg-white/5 rounded-xl border border-white/10">
                <h4 className="text-lg font-semibold text-white mb-3">カスタム雑誌追加</h4>
                <div className="flex space-x-3">
                  <input
                    type="text"
                    placeholder="雑誌名を入力..."
                    className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/60 focus:ring-2 focus:ring-green-400/50 focus:border-green-400/50"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        const input = e.target as HTMLInputElement;
                        const journalName = input.value.trim();
                        if (journalName && !customJournals.includes(journalName)) {
                          setCustomJournals(prev => [...prev, journalName]);
                          input.value = '';
                        }
                      }
                    }}
                  />
                  <button
                    onClick={() => {
                      const input = document.querySelector('input[placeholder="雑誌名を入力..."]') as HTMLInputElement;
                      const journalName = input?.value.trim();
                      if (journalName && !customJournals.includes(journalName)) {
                        setCustomJournals(prev => [...prev, journalName]);
                        input.value = '';
                      }
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-xl hover:from-green-700 hover:to-teal-700 transition-all duration-300 transform hover:scale-105"
                  >
                    追加
                  </button>
                </div>
                <p className="text-xs text-white/60 mt-2">
                  Enterキーまたは「追加」ボタンで雑誌を追加できます
                </p>
              </div>
            </div>

            {/* Articles List */}
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <RefreshCw className="h-12 w-12 text-blue-400 animate-spin mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">
                    {lastUpdated ? '新着論文を検索中...' : '医学文献データを取得中...'}
                  </h3>
                  <p className="text-white/70">
                    {lastUpdated 
                      ? `最終更新日（${new Date(lastUpdated).toLocaleDateString('ja-JP')}）以降の新しい論文を収集しています`
                      : '選択された診療科の専門雑誌から過去7日間の論文を収集しています'
                    }
                  </p>
                  <p className="text-white/50 text-sm mt-2">
                    PubMed API と CrossRef API から並行取得中...
                  </p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {filteredAndSortedArticles.map(article => (
                  <div
                    key={article.id}
                    className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-[1.02]"
                  >
                    {/* Article Header */}
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center space-x-3 flex-wrap">
                        <span className={`px-3 py-1 text-sm font-bold rounded-full ${getEvidenceBadgeColor(article.evidenceLevel)}`}>
                          エビデンスレベル {article.evidenceLevel}
                        </span>
                        <span className="px-3 py-1 text-sm font-medium bg-blue-500/20 text-blue-300 rounded-full border border-blue-400/30">
                          {article.specialty}
                        </span>
                        <span className="px-3 py-1 text-sm font-medium bg-purple-500/20 text-purple-300 rounded-full border border-purple-400/30">
                          {article.category}
                        </span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleGenerateAISummary(article)}
                          className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-300"
                          title="AI要約生成"
                        >
                          <RefreshCw className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleAudioGeneration(article)}
                          className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-300"
                          title="音声生成"
                        >
                          <Volume2 className="h-4 w-4" />
                        </button>
                        <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-300">
                          <Share2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className="text-xl font-bold text-white mb-2">
                      {article.title}
                    </h3>

                    {/* Meta Info */}
                    <div className="flex items-center space-x-4 text-sm text-white/70 mb-4">
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span>{article.authors.slice(0, 3).join(', ')}{article.authors.length > 3 ? ' et al.' : ''}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <BookOpen className="h-4 w-4" />
                        <span>{article.journalName}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>{article.publishDate}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{article.readingTime}</span>
                      </div>
                    </div>

                    {/* Summary */}
                    <div className="mb-4">
                      <h4 className="text-lg font-semibold text-white mb-2">要約</h4>
                      <p className="text-white/90 leading-relaxed">
                        {article.summaryJapanese ? (
                          <span dangerouslySetInnerHTML={{ 
                            __html: article.summaryJapanese.replace(/\n/g, '<br/>') 
                          }} />
                        ) : (
                          article.summary
                        )}
                      </p>
                    </div>

                    {/* Keywords */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {article.keywords.map((keyword, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-white/10 text-white/80 rounded-full text-xs border border-white/20"
                        >
                          {keyword}
                        </span>
                      ))}
                    </div>

                    {/* Actions */}
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-white/60">
                        <span className="font-medium">DOI: </span>
                        <a
                          href={article.url || `https://doi.org/${article.doi}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-300 hover:text-blue-200 transition-colors"
                        >
                          {article.doi}
                        </a>
                      </div>
                      
                      <div className="flex space-x-2">
                        {article.audioUrl && (
                          <button className="px-4 py-2 bg-green-500/20 text-green-300 rounded-xl hover:bg-green-500/30 transition-all duration-300 flex items-center space-x-1">
                            <Headphones className="h-4 w-4" />
                            <span>音声再生</span>
                          </button>
                        )}
                        {article.url && (
                          <a
                            href={article.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-4 py-2 bg-blue-500/20 text-blue-300 rounded-xl hover:bg-blue-500/30 transition-all duration-300"
                          >
                            原文を読む
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* No Results Message */}
            {!isLoading && filteredAndSortedArticles.length === 0 && articles.length > 0 && (
              <div className="text-center py-12">
                <Filter className="h-12 w-12 text-white/40 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">フィルター条件に一致する論文がありません</h3>
                <p className="text-white/70 mb-4">雑誌選択やフィルター条件を変更してお試しください</p>
                <div className="flex justify-center space-x-4">
                  <button
                    onClick={() => setSelectedJournals(['all'])}
                    className="px-4 py-2 bg-blue-500/20 text-blue-300 rounded-xl hover:bg-blue-500/30 transition-all duration-300"
                  >
                    全ての雑誌を表示
                  </button>
                  <button
                    onClick={() => setFilterBy('all')}
                    className="px-4 py-2 bg-green-500/20 text-green-300 rounded-xl hover:bg-green-500/30 transition-all duration-300"
                  >
                    全ての期間を表示
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            {/* Weekly Update Settings */}
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">週次更新設定</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-white/80 mb-2">更新曜日</label>
                  <select
                    value={weeklyConfig.dayOfWeek}
                    onChange={(e) => setWeeklyConfig(prev => ({ ...prev, dayOfWeek: parseInt(e.target.value) }))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-blue-400/50"
                  >
                    <option value={0}>日曜日</option>
                    <option value={1}>月曜日</option>
                    <option value={2}>火曜日</option>
                    <option value={3}>水曜日</option>
                    <option value={4}>木曜日</option>
                    <option value={5}>金曜日</option>
                    <option value={6}>土曜日</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-white/80 mb-2">更新時刻</label>
                  <input
                    type="time"
                    value={weeklyConfig.timeOfDay}
                    onChange={(e) => setWeeklyConfig(prev => ({ ...prev, timeOfDay: e.target.value }))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-blue-400/50"
                  />
                </div>
              </div>
            </div>

            {/* Slack Settings */}
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">Slack連携設定</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-white/80 mb-2">Webhook URL</label>
                  <input
                    type="url"
                    value={weeklyConfig.slackWebhookUrl}
                    onChange={(e) => setWeeklyConfig(prev => ({ ...prev, slackWebhookUrl: e.target.value }))}
                    placeholder="https://hooks.slack.com/services/..."
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-blue-400/50"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-white/80 mb-2">投稿チャンネル</label>
                  <input
                    type="text"
                    value={weeklyConfig.slackChannel}
                    onChange={(e) => setWeeklyConfig(prev => ({ ...prev, slackChannel: e.target.value }))}
                    placeholder="#medical-literature"
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-blue-400/50"
                  />
                </div>
                
                <button
                  onClick={handleSlackPost}
                  className="px-6 py-3 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-xl hover:from-green-700 hover:to-blue-700 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center space-x-2"
                >
                  <Send className="h-5 w-5" />
                  <span>テスト投稿</span>
                </button>
              </div>
            </div>

            {/* AI Summary Settings */}
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">AI要約設定</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-white/80 mb-2">要約文字数</label>
                  <input
                    type="range"
                    min="400"
                    max="800"
                    value={aiConfig.targetLength}
                    onChange={(e) => setAiConfig(prev => ({ ...prev, targetLength: parseInt(e.target.value) }))}
                    className="w-full"
                  />
                  <div className="text-sm text-white/70 mt-1">{aiConfig.targetLength}字</div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-white/80 mb-2">要約スタイル</label>
                  <select
                    value={aiConfig.summaryStyle}
                    onChange={(e) => setAiConfig(prev => ({ ...prev, summaryStyle: e.target.value as any }))}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-blue-400/50"
                  >
                    <option value="clinical">臨床重視</option>
                    <option value="detailed">詳細</option>
                    <option value="concise">簡潔</option>
                  </select>
                </div>
              </div>
              
              <div className="mt-4 space-y-3">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={aiConfig.includeTranslation}
                    onChange={(e) => setAiConfig(prev => ({ ...prev, includeTranslation: e.target.checked }))}
                    className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                  />
                  <span className="text-white">日本語翻訳を含める</span>
                </label>
                
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={aiConfig.preserveTechnicalTerms}
                    onChange={(e) => setAiConfig(prev => ({ ...prev, preserveTechnicalTerms: e.target.checked }))}
                    className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                  />
                  <span className="text-white">専門用語を保持</span>
                </label>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'export' && (
          <div className="space-y-6">
            {/* Export Options */}
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">エクスポート設定</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-3">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={outputConfig.enablePDF}
                      onChange={(e) => setOutputConfig(prev => ({ ...prev, enablePDF: e.target.checked }))}
                      className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                    />
                    <span className="text-white">PDF出力</span>
                  </label>
                  
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={outputConfig.enableMarkdown}
                      onChange={(e) => setOutputConfig(prev => ({ ...prev, enableMarkdown: e.target.checked }))}
                      className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                    />
                    <span className="text-white">Markdown出力</span>
                  </label>
                  
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={outputConfig.obsidianCompatible}
                      onChange={(e) => setOutputConfig(prev => ({ ...prev, obsidianCompatible: e.target.checked }))}
                      className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                    />
                    <span className="text-white">Obsidian対応</span>
                  </label>
                </div>
                
                <div className="space-y-3">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={outputConfig.enableAudio}
                      onChange={(e) => setOutputConfig(prev => ({ ...prev, enableAudio: e.target.checked }))}
                      className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                    />
                    <span className="text-white">音声出力</span>
                  </label>
                  
                  <div>
                    <label className="block text-sm font-medium text-white/80 mb-1">音声言語</label>
                    <select
                      value={outputConfig.audioLanguage}
                      onChange={(e) => setOutputConfig(prev => ({ ...prev, audioLanguage: e.target.value as any }))}
                      className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-xl text-white text-sm focus:ring-2 focus:ring-blue-400/50"
                    >
                      <option value="ja-JP">日本語</option>
                      <option value="en-US">英語</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-white/80 mb-1">音声速度</label>
                    <input
                      type="range"
                      min="0.5"
                      max="2.0"
                      step="0.1"
                      value={outputConfig.audioSpeed}
                      onChange={(e) => setOutputConfig(prev => ({ ...prev, audioSpeed: parseFloat(e.target.value) }))}
                      className="w-full"
                    />
                    <div className="text-sm text-white/70 mt-1">{outputConfig.audioSpeed}x</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Export Actions */}
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-white mb-4">エクスポート実行</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button
                  onClick={handlePDFExport}
                  disabled={!outputConfig.enablePDF}
                  className="flex items-center justify-center space-x-2 px-6 py-4 bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-xl hover:from-red-700 hover:to-pink-700 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <FileText className="h-5 w-5" />
                  <span>PDF出力</span>
                </button>
                
                <button
                  onClick={handleMarkdownExport}
                  disabled={!outputConfig.enableMarkdown}
                  className="flex items-center justify-center space-x-2 px-6 py-4 bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-xl hover:from-green-700 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <FileText className="h-5 w-5" />
                  <span>Markdown出力</span>
                </button>
                
                <button
                  onClick={handleSlackPost}
                  className="flex items-center justify-center space-x-2 px-6 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  <Send className="h-5 w-5" />
                  <span>Slack投稿</span>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <h2 className="text-2xl font-bold text-white mb-6">エクスポート設定</h2>
              
              {/* PDF出力設定 */}
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <h3 className="text-lg font-bold text-white mb-4">PDF出力設定</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <label className="block text-sm font-medium text-white/80 mb-2">
                      フォントサイズ
                    </label>
                    <select 
                      value={pdfSettings.fontSize}
                      onChange={(e) => setPdfSettings({...pdfSettings, fontSize: parseInt(e.target.value)})}
                      className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-blue-400/50"
                    >
                      <option value={10}>10pt (小)</option>
                      <option value={12}>12pt (標準)</option>
                      <option value={14}>14pt (大)</option>
                      <option value={16}>16pt (特大)</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-white/80 mb-2">
                      用紙サイズ
                    </label>
                    <select 
                      value={pdfSettings.paperSize}
                      onChange={(e) => setPdfSettings({...pdfSettings, paperSize: e.target.value})}
                      className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-blue-400/50"
                    >
                      <option value="A4">A4</option>
                      <option value="A3">A3</option>
                      <option value="Letter">Letter</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-white/80 mb-2">
                      文字エンコーディング
                    </label>
                    <select 
                      value={pdfSettings.encoding}
                      onChange={(e) => setPdfSettings({...pdfSettings, encoding: e.target.value})}
                      className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-blue-400/50"
                    >
                      <option value="UTF-8">UTF-8 (推奨)</option>
                      <option value="Shift_JIS">Shift_JIS</option>
                      <option value="EUC-JP">EUC-JP</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-white/80 mb-2">
                      フォント
                    </label>
                    <select 
                      value={pdfSettings.fontFamily}
                      onChange={(e) => setPdfSettings({...pdfSettings, fontFamily: e.target.value})}
                      className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-blue-400/50"
                    >
                      <option value="NotoSansJP">Noto Sans JP (推奨)</option>
                      <option value="MSGothic">MS ゴシック</option>
                      <option value="MSMincho">MS 明朝</option>
                      <option value="Arial">Arial</option>
                    </select>
                  </div>
                </div>
                
                <div className="space-y-4 mb-6">
                  <label className="flex items-center space-x-3">
                    <input 
                      type="checkbox" 
                      checked={pdfSettings.includeImages}
                      onChange={(e) => setPdfSettings({...pdfSettings, includeImages: e.target.checked})}
                      className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                    />
                    <span className="text-white/80">画像を含める</span>
                  </label>
                  
                  <label className="flex items-center space-x-3">
                    <input 
                      type="checkbox" 
                      checked={pdfSettings.includeReferences}
                      onChange={(e) => setPdfSettings({...pdfSettings, includeReferences: e.target.checked})}
                      className="h-4 w-4 text-blue-400 focus:ring-blue-400/50 border-white/30 rounded bg-white/10"
                    />
                    <span className="text-white/80">参考文献を含める</span>
                  </label>
                </div>
                
                <div className="bg-blue-500/20 border border-blue-400/30 rounded-xl p-4 mb-6">
                  <h4 className="text-blue-200 font-medium mb-2">📝 日本語PDF出力について</h4>
                  <ul className="text-blue-200/80 text-sm space-y-1">
                    <li>• UTF-8エンコーディングで日本語文字化けを防止</li>
                    <li>• Noto Sans JPフォントで美しい日本語表示</li>
                    <li>• 論文タイトルと要約の日本語版を優先表示</li>
                    <li>• 改ページ処理で読みやすいレイアウト</li>
                  </ul>
                </div>
                
                <button
                  onClick={() => generatePDF([])}
                  className="px-6 py-3 bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-xl hover:from-red-700 hover:to-pink-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  PDF生成
                </button>
              </div>
              
              {/* Markdown出力設定 */}
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <h3 className="text-lg font-bold text-white mb-4">Markdown出力</h3>
                <p className="text-white/80 mb-4">Obsidian対応のMarkdownファイルを生成します</p>
                
                <div className="bg-green-500/20 border border-green-400/30 rounded-xl p-4 mb-6">
                  <h4 className="text-green-200 font-medium mb-2">📋 Markdown出力の特徴</h4>
                  <ul className="text-green-200/80 text-sm space-y-1">
                    <li>• 日本語タイトルと要約を優先表示</li>
                    <li>• Obsidianのリンク記法に対応</li>
                    <li>• タグ機能で専門分野とキーワードを整理</li>
                    <li>• 構造化された読みやすいフォーマット</li>
                  </ul>
                </div>
                
                <button 
                  onClick={() => generateMarkdown([], true)}
                  className="px-6 py-3 bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-xl hover:from-green-700 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  Markdown生成
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MedicalLiteratureSystem;