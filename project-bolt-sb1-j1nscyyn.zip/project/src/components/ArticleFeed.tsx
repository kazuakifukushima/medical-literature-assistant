import React, { useState } from 'react';
import ArticleCard from './ArticleCard';
import { Filter, SortAsc, Calendar, Search } from 'lucide-react';

interface Article {
  id: string;
  title: string;
  authors: string[];
  journal: string;
  publishDate: string;
  summary: string;
  evidenceLevel: 'A' | 'B' | 'C';
  specialty: string;
  isFavorited: boolean;
  readingTime: string;
  citations: number;
}

interface ArticleFeedProps {
  searchQuery: string;
  selectedSpecialty: string;
  selectedJournals: string[];
  sortBy: string;
  filterBy: string;
  onSortChange: (sort: string) => void;
  onFilterChange: (filter: string) => void;
}

const ArticleFeed: React.FC<ArticleFeedProps> = ({ 
  searchQuery, 
  selectedSpecialty, 
  selectedJournals,
  sortBy,
  filterBy,
  onSortChange,
  onFilterChange
}) => {
  
  const mockArticles: Article[] = [
    {
      id: '1',
      title: 'CRISPR遺伝子治療による遺伝性失明の根本治療: 第III相臨床試験結果',
      authors: ['田中太郎', '山田花子', '佐藤次郎', 'Smith JA', 'Johnson MB'],
      journal: 'nature-medicine',
      journalName: 'Nature Medicine',
      publishDate: '2024-12-18',
      summary: 'レーバー先天性黒内障患者を対象とした第III相臨床試験において、CRISPR-Cas9遺伝子治療が95%の患者で視力改善を実現。従来不可能とされた遺伝性眼疾患の根本治療への道筋を示す画期的な成果。重篤な副作用は報告されず、長期安全性も良好。',
      evidenceLevel: 'A',
      specialty: '眼科',
      isFavorited: false,
      readingTime: '12分',
      citations: 234
    },
    {
      id: '2',
      title: 'AI創薬による次世代COVID-19治療薬の開発: 変異株耐性メカニズムの解明',
      authors: ['高橋誠', '鈴木美咲', '中村健一', 'Williams CD', 'Brown KL'],
      journal: 'nejm',
      journalName: 'New England Journal of Medicine',
      publishDate: '2024-12-17',
      summary: '機械学習アルゴリズムを用いた創薬プラットフォームにより、COVID-19の新変異株に対しても有効性を維持する治療薬候補を特定。従来の薬剤開発期間を80%短縮し、パンデミック対応の新パラダイムを提示。前臨床試験で顕著な抗ウイルス効果を確認。',
      evidenceLevel: 'A',
      specialty: '感染症科',
      isFavorited: true,
      readingTime: '15分',
      citations: 189
    },
    {
      id: '3',
      title: '個別化がんワクチンによる転移予防: mRNA技術を応用した精密医療の新展開',
      authors: ['渡辺明子', '小林正樹', 'Davis RP', 'Miller SJ'],
      journal: 'lancet',
      journalName: 'The Lancet',
      publishDate: '2024-12-16',
      summary: '患者固有の腫瘍抗原を標的とした個別化がんワクチンが、術後転移予防において89%の有効性を実証。mRNAワクチン技術を応用し、免疫系を活性化して微小転移を排除。従来の化学療法と比較して副作用が大幅に軽減され、QOLの向上も確認。',
      evidenceLevel: 'A',
      specialty: '腫瘍科',
      isFavorited: false,
      readingTime: '18分',
      citations: 312
    },
    {
      id: '4',
      title: '異種移植による心臓移植の成功: 遺伝子改変豚心臓の長期生着',
      authors: ['伊藤健一', '松本美穂', 'Anderson TK', 'Wilson PL'],
      journal: 'nejm',
      journalName: 'New England Journal of Medicine',
      publishDate: '2024-12-15',
      summary: '遺伝子改変豚の心臓を用いた異種移植手術が成功し、患者は術後6ヶ月間良好な経過を示している。10個の遺伝子改変により免疫拒絶反応を最小化し、臓器不足問題の根本的解決策として期待。国際的な倫理委員会の承認も得て、移植医療の新時代を開拓。',
      evidenceLevel: 'A',
      specialty: '外科',
      isFavorited: false,
      readingTime: '20分',
      citations: 156
    },
    {
      id: '5',
      title: 'デジタル治療によるうつ病治療: AI搭載アプリの大規模臨床試験',
      authors: ['佐々木雄一', '岡田真理', 'Thompson GH', 'Lee MK'],
      journal: 'jama',
      journalName: 'Journal of the American Medical Association',
      publishDate: '2024-12-14',
      summary: 'AI搭載のデジタル治療アプリが、うつ病症状を72%改善する効果を無作為化比較試験で実証。認知行動療法とパーソナライズされた介入を組み合わせ、従来の薬物療法と同等の効果を達成。治療アクセシビリティの向上と医療費削減にも貢献。',
      evidenceLevel: 'A',
      specialty: '精神科',
      isFavorited: true,
      readingTime: '13分',
      citations: 98
    },
    {
      id: '6',
      title: '幹細胞治療による脊髄損傷の機能回復: iPS細胞移植の長期追跡結果',
      authors: ['木村直樹', '中島恵子', 'Garcia ML', 'Rodriguez AJ'],
      journal: 'nature-medicine',
      journalName: 'Nature Medicine',
      publishDate: '2024-12-13',
      summary: '完全脊髄損傷患者に対するiPS細胞由来神経前駆細胞移植により、運動機能の部分的回復を実現。移植後12ヶ月で下肢の随意運動が回復し、歩行補助具を用いた移動が可能に。神経再生医学の画期的な進歩として国際的に注目。',
      evidenceLevel: 'A',
      specialty: '神経内科',
      isFavorited: false,
      readingTime: '19分',
      citations: 267
    }
  ];

  const filteredArticles = mockArticles.filter(article => {
    const matchesSearch = searchQuery === '' || 
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.authors.some(author => author.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesSpecialty = selectedSpecialty === 'all' || 
      article.specialty === selectedSpecialty;
    
    const matchesJournal = selectedJournals.includes('all') || 
      selectedJournals.includes(article.journal);
    
    return matchesSearch && matchesSpecialty && matchesJournal;
  });

  const handleToggleFavorite = (id: string) => {
    console.log('Toggle favorite:', id);
  };

  const handleExport = (id: string) => {
    console.log('Export article:', id);
  };

  const handleGenerateAudio = (id: string) => {
    console.log('Generate audio:', id);
  };

  return (
    <div className="p-6 relative">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-white via-blue-200 to-purple-200 bg-clip-text text-transparent">論文フィード</h2>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-white/60" />
            <select 
              value={filterBy}
              onChange={(e) => onFilterChange(e.target.value)}
              className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-2 text-sm text-white focus:ring-2 focus:ring-blue-400/50 focus:border-blue-400/50"
            >
              <option value="all">全て</option>
              <option value="favorites">お気に入り</option>
              <option value="unread">未読</option>
              <option value="recent">最近追加</option>
            </select>
          </div>
          
          <div className="flex items-center space-x-2">
            <SortAsc className="h-4 w-4 text-white/60" />
            <select 
              value={sortBy}
              onChange={(e) => onSortChange(e.target.value)}
              className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-2 text-sm text-white focus:ring-2 focus:ring-blue-400/50 focus:border-blue-400/50"
            >
              <option value="date">発表日</option>
              <option value="relevance">関連度</option>
              <option value="citations">引用数</option>
              <option value="evidence">エビデンスレベル</option>
            </select>
          </div>
        </div>
      </div>

      <div className="mb-6 p-4 bg-blue-500/20 backdrop-blur-sm rounded-xl border border-blue-400/30">
        <div className="flex items-center space-x-2 text-blue-200">
          <Calendar className="h-4 w-4" />
          <span className="text-sm font-medium">
            {filteredArticles.length} 件の論文が見つかりました
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {filteredArticles.map((article) => (
          <ArticleCard
            key={article.id}
            article={article}
            onToggleFavorite={handleToggleFavorite}
            onExport={handleExport}
            onGenerateAudio={handleGenerateAudio}
          />
        ))}
      </div>

      {filteredArticles.length === 0 && (
        <div className="text-center py-12">
          <Search className="h-12 w-12 text-white/40 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">論文が見つかりませんでした</h3>
          <p className="text-white/70">検索条件を変更してお試しください</p>
        </div>
      )}
    </div>
  );
};

export default ArticleFeed;