import React, { useState, useEffect } from 'react';
import { 
  ExternalLink, 
  Calendar, 
  Users, 
  BookOpen, 
  Star, 
  Download, 
  Play,
  Clock,
  Award,
  TrendingUp,
  Eye,
  Share2,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Database,
  Globe,
  Filter
} from 'lucide-react';
import { fetchIntegratedLancetData, LancetArticleData } from '../services/lancet-api';

interface FetchStatus {
  isLoading: boolean;
  lastUpdated: string | null;
  error: string | null;
  sources: {
    lancet: boolean;
    pubmed: boolean;
  };
  totalAttempted: number;
  successfulSources: string[];
}

const LancetSection: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<LancetArticleData | null>(null);
  const [activeCategory, setActiveCategory] = useState('all');
  const [activeJournal, setActiveJournal] = useState('all');
  const [articles, setArticles] = useState<LancetArticleData[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [fetchStatus, setFetchStatus] = useState<FetchStatus>({
    isLoading: false,
    lastUpdated: null,
    error: null,
    sources: {
      lancet: false,
      pubmed: false
    },
    totalAttempted: 0,
    successfulSources: []
  });

  // データ取得関数
  const loadLatestArticles = async () => {
    setFetchStatus(prev => ({ 
      ...prev, 
      isLoading: true, 
      error: null,
      sources: { lancet: false, pubmed: false },
      totalAttempted: prev.totalAttempted + 1,
      successfulSources: []
    }));
    
    try {
      console.log(`🔄 The Lancet統合データ取得を開始... (試行回数: ${fetchStatus.totalAttempted + 1})`);
      const latestArticles = await fetchIntegratedLancetData();
      
      const successfulSources = [];
      if (latestArticles.some(a => a.source === 'lancet')) successfulSources.push('The Lancet RSS/Web');
      if (latestArticles.some(a => a.source === 'pubmed')) successfulSources.push('PubMed API');
      
      setArticles(latestArticles);
      setFetchStatus({
        isLoading: false,
        lastUpdated: new Date().toLocaleString('ja-JP'),
        error: latestArticles.length === 0 ? 'データの取得に成功しましたが、新しい論文が見つかりませんでした。' : null,
        sources: {
          lancet: latestArticles.some(a => a.source === 'lancet'),
          pubmed: latestArticles.some(a => a.source === 'pubmed')
        },
        totalAttempted: fetchStatus.totalAttempted + 1,
        successfulSources
      });
      
      console.log(`✅ ${latestArticles.length}件のThe Lancet論文データを取得完了 (ソース: ${successfulSources.join(', ')})`);
    } catch (error) {
      console.error('❌ データ取得エラー:', error);
      setFetchStatus({
        isLoading: false,
        lastUpdated: null,
        error: 'リアルタイムデータの取得に失敗しました。CORS制限またはネットワーク接続の問題が考えられます。',
        sources: { lancet: false, pubmed: false },
        totalAttempted: fetchStatus.totalAttempted + 1,
        successfulSources: []
      });
    }
  };

  // ブラウザ開始時のみデータを取得（自動更新なし）
  useEffect(() => {
    loadLatestArticles();
  }, []); // 依存配列を空にして初回のみ実行

  // The Lancet系列雑誌のリスト
  const lancetJournals = [
    { id: 'all', label: '全てのLancet系雑誌', count: articles.length },
    { id: 'The Lancet', label: 'The Lancet', count: articles.filter(a => a.journal === 'The Lancet').length },
    { id: 'The Lancet Oncology', label: 'The Lancet Oncology', count: articles.filter(a => a.journal === 'The Lancet Oncology').length },
    { id: 'The Lancet Neurology', label: 'The Lancet Neurology', count: articles.filter(a => a.journal === 'The Lancet Neurology').length },
    { id: 'The Lancet Psychiatry', label: 'The Lancet Psychiatry', count: articles.filter(a => a.journal === 'The Lancet Psychiatry').length },
    { id: 'The Lancet Infectious Diseases', label: 'The Lancet Infectious Diseases', count: articles.filter(a => a.journal === 'The Lancet Infectious Diseases').length },
    { id: 'The Lancet Respiratory Medicine', label: 'The Lancet Respiratory Medicine', count: articles.filter(a => a.journal === 'The Lancet Respiratory Medicine').length },
    { id: 'The Lancet Diabetes & Endocrinology', label: 'The Lancet Diabetes & Endocrinology', count: articles.filter(a => a.journal === 'The Lancet Diabetes & Endocrinology').length },
    { id: 'The Lancet Gastroenterology & Hepatology', label: 'The Lancet Gastroenterology & Hepatology', count: articles.filter(a => a.journal === 'The Lancet Gastroenterology & Hepatology').length },
    { id: 'The Lancet Haematology', label: 'The Lancet Haematology', count: articles.filter(a => a.journal === 'The Lancet Haematology').length },
    { id: 'The Lancet Rheumatology', label: 'The Lancet Rheumatology', count: articles.filter(a => a.journal === 'The Lancet Rheumatology').length },
    { id: 'The Lancet Child & Adolescent Health', label: 'The Lancet Child & Adolescent Health', count: articles.filter(a => a.journal === 'The Lancet Child & Adolescent Health').length },
    { id: 'The Lancet Global Health', label: 'The Lancet Global Health', count: articles.filter(a => a.journal === 'The Lancet Global Health').length },
    { id: 'The Lancet Public Health', label: 'The Lancet Public Health', count: articles.filter(a => a.journal === 'The Lancet Public Health').length },
    { id: 'The Lancet Digital Health', label: 'The Lancet Digital Health', count: articles.filter(a => a.journal === 'The Lancet Digital Health').length },
    { id: 'The Lancet Planetary Health', label: 'The Lancet Planetary Health', count: articles.filter(a => a.journal === 'The Lancet Planetary Health').length },
  ];

  const categories = [
    { id: 'all', label: '全ての記事', count: articles.length },
    { id: 'Original Article', label: 'Original Articles', count: articles.filter(a => a.category === 'Original Article').length },
    { id: 'Review', label: 'Reviews', count: articles.filter(a => a.category === 'Review').length },
    { id: 'Systematic Review', label: 'Systematic Reviews', count: articles.filter(a => a.category === 'Systematic Review').length },
    { id: 'Comment', label: 'Comments', count: articles.filter(a => a.category === 'Comment').length },
    { id: 'Correspondence', label: 'Correspondence', count: articles.filter(a => a.category === 'Correspondence').length },
    { id: 'Editorial', label: 'Editorials', count: articles.filter(a => a.category === 'Editorial').length }
  ];

  const filteredArticles = articles.filter(article => {
    const matchesCategory = activeCategory === 'all' || article.category === activeCategory;
    const matchesJournal = activeJournal === 'all' || article.journal === activeJournal;
    return matchesCategory && matchesJournal;
  });

  const handleArticleClick = (article: LancetArticleData) => {
    setSelectedArticle(article);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    // モーダルのアニメーション完了後にselectedArticleをクリア
    setTimeout(() => {
      setSelectedArticle(null);
    }, 300);
  };

  const getEvidenceBadgeColor = (level: string) => {
    switch (level) {
      case 'A': return 'bg-green-500/20 text-green-300 border border-green-400/30';
      case 'B': return 'bg-yellow-500/20 text-yellow-300 border border-yellow-400/30';
      case 'C': return 'bg-red-500/20 text-red-300 border border-red-400/30';
      default: return 'bg-gray-500/20 text-gray-300 border border-gray-400/30';
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'lancet': return <Globe className="h-3 w-3" />;
      case 'pubmed': return <Database className="h-3 w-3" />;
      default: return <BookOpen className="h-3 w-3" />;
    }
  };

  const getSourceColor = (source: string) => {
    switch (source) {
      case 'lancet': return 'bg-red-500/20 text-red-300 border border-red-400/30';
      case 'pubmed': return 'bg-blue-500/20 text-blue-300 border border-blue-400/30';
      default: return 'bg-gray-500/20 text-gray-300 border border-gray-400/30';
    }
  };

  const getJournalColor = (journal: string) => {
    const colors = {
      'The Lancet': 'bg-red-600/20 text-red-300 border border-red-500/30',
      'The Lancet Oncology': 'bg-purple-600/20 text-purple-300 border border-purple-500/30',
      'The Lancet Neurology': 'bg-blue-600/20 text-blue-300 border border-blue-500/30',
      'The Lancet Psychiatry': 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30',
      'The Lancet Global Health': 'bg-green-600/20 text-green-300 border border-green-500/30',
      'The Lancet Digital Health': 'bg-cyan-600/20 text-cyan-300 border border-cyan-500/30',
      'The Lancet Planetary Health': 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/30',
    };
    return colors[journal as keyof typeof colors] || 'bg-gray-600/20 text-gray-300 border border-gray-500/30';
  };

  return (
    <div className="space-y-8">
      {/* The Lancet Header with Integrated Data Status */}
      <div className="bg-gradient-to-r from-red-900/20 to-orange-900/20 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="w-20 h-20 bg-gradient-to-br from-red-600 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-lg">TL</span>
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">The Lancet</h2>
              <div className="flex items-center space-x-6 text-white/80">
                <div className="flex items-center space-x-2">
                  <Award className="h-5 w-5 text-yellow-400" />
                  <span className="font-semibold">Impact Factor: 168.9</span>
                </div>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-green-400" />
                  <span>統合データソース対応</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-blue-400" />
                  <span>1823年創刊</span>
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {/* Data Source Status */}
            <div className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
              <div className="flex items-center space-x-1">
                <Globe className={`h-4 w-4 ${fetchStatus.sources.lancet ? 'text-green-400' : 'text-gray-400'}`} />
                <span className="text-xs text-white/80">Lancet</span>
              </div>
              <div className="w-px h-4 bg-white/20"></div>
              <div className="flex items-center space-x-1">
                <Database className={`h-4 w-4 ${fetchStatus.sources.pubmed ? 'text-green-400' : 'text-gray-400'}`} />
                <span className="text-xs text-white/80">PubMed</span>
              </div>
            </div>

            {/* Real-time Status Indicator */}
            <div className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
              {fetchStatus.isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 text-blue-400 animate-spin" />
                  <span className="text-sm text-blue-200">統合中...</span>
                </>
              ) : fetchStatus.error ? (
                <>
                  <AlertCircle className="h-4 w-4 text-red-400" />
                  <span className="text-sm text-red-200">エラー</span>
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <span className="text-sm text-green-200">最新</span>
                </>
              )}
            </div>
            
            {/* Manual Refresh Button */}
            <button
              onClick={loadLatestArticles}
              disabled={fetchStatus.isLoading}
              className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <RefreshCw className={`h-4 w-4 ${fetchStatus.isLoading ? 'animate-spin' : ''}`} />
              <span className="text-sm font-medium">統合更新</span>
            </button>
            
            <a 
              href="https://www.thelancet.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-red-600 to-orange-600 text-white rounded-xl hover:from-red-700 hover:to-orange-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <ExternalLink className="h-5 w-5" />
              <span className="font-semibold">TheLancet.com</span>
            </a>
          </div>
        </div>
        
        {/* Last Updated Info with Source Details */}
        {fetchStatus.lastUpdated && (
          <div className="mt-4 flex items-center justify-between">
            <div className="flex items-center space-x-2 text-sm text-white/60">
              <Clock className="h-4 w-4" />
              <span>最終更新: {fetchStatus.lastUpdated}</span>
              <span className="mx-2">•</span>
              <span>{articles.length} 件の統合論文</span>
              <span className="mx-2">•</span>
              <span>試行回数: {fetchStatus.totalAttempted}</span>
            </div>
            <div className="flex items-center space-x-4 text-xs text-white/60">
              {fetchStatus.successfulSources.length > 0 ? (
                <div className="flex items-center space-x-2">
                  <span>成功ソース: {fetchStatus.successfulSources.join(', ')}</span>
                </div>
              ) : (
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    <Globe className="h-3 w-3" />
                    <span>Lancet直接: {articles.filter(a => a.source === 'lancet').length}件</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Database className="h-3 w-3" />
                    <span>PubMed経由: {articles.filter(a => a.source === 'pubmed').length}件</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Error Message */}
        {fetchStatus.error && (
          <div className="mt-4 p-4 bg-red-500/20 border border-red-400/30 rounded-xl">
            <div className="flex items-center space-x-2 text-red-200">
              <AlertCircle className="h-5 w-5" />
              <span className="font-medium">リアルタイムデータ取得状況</span>
            </div>
            <p className="text-sm text-red-300 mt-1">{fetchStatus.error}</p>
            <div className="mt-3 space-y-1 text-xs text-red-400">
              <p>• The Lancet公式サイト: RSS Feed + Webスクレイピング</p>
              <p>• PubMed API: 最近30日間のThe Lancet論文検索</p>
              <p>• CORS制限回避: プロキシサービス使用</p>
              <p className="mt-2 font-medium">手動更新ボタンで再試行してください。</p>
            </div>
          </div>
        )}
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Journal Filter */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Lancet系雑誌</span>
          </h3>
          <div className="grid grid-cols-1 gap-2 max-h-64 overflow-y-auto">
            {lancetJournals.map((journal) => (
              <button
                key={journal.id}
                onClick={() => setActiveJournal(journal.id)}
                className={`px-4 py-2 rounded-xl transition-all duration-300 transform hover:scale-105 text-left ${
                  activeJournal === journal.id
                    ? 'bg-gradient-to-r from-red-500/30 to-orange-500/30 text-white border border-red-400/50 shadow-lg'
                    : 'bg-white/10 text-white/80 hover:bg-white/20 border border-white/20'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium text-sm">{journal.label}</span>
                  {journal.count > 0 && (
                    <span className="px-2 py-1 bg-white/20 rounded-full text-xs">
                      {journal.count}
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Category Filter */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4">記事カテゴリー</h3>
          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-4 py-2 rounded-xl transition-all duration-300 transform hover:scale-105 ${
                  activeCategory === category.id
                    ? 'bg-gradient-to-r from-red-500/30 to-orange-500/30 text-white border border-red-400/50 shadow-lg'
                    : 'bg-white/10 text-white/80 hover:bg-white/20 border border-white/20'
                }`}
              >
                <span className="font-medium">{category.label}</span>
                {category.count > 0 && (
                  <span className="ml-2 px-2 py-1 bg-white/20 rounded-full text-xs">
                    {category.count}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Loading State */}
      {fetchStatus.isLoading && articles.length === 0 && (
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-4 mb-4">
              <RefreshCw className="h-8 w-8 text-red-400 animate-spin" />
              <div className="flex space-x-2">
                <Globe className="h-6 w-6 text-red-400 animate-pulse" />
                <Database className="h-6 w-6 text-blue-400 animate-pulse" />
              </div>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">リアルタイムデータを取得中...</h3>
            <div className="text-white/70 space-y-1">
              <p>The Lancet公式サイト (RSS + Web) から最新論文を収集中</p>
              <p>PubMed APIから最近30日間の論文を検索中</p>
              <p className="text-sm text-white/50">CORS制限回避のためプロキシサービスを使用</p>
            </div>
          </div>
        </div>
      )}

      {/* Articles Grid */}
      {!fetchStatus.isLoading && (
        <div className="grid grid-cols-1 gap-8">
          {filteredArticles.map((article) => (
            <div 
              key={article.id}
              className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/20 overflow-hidden hover:bg-white/20 transition-all duration-500 transform hover:scale-[1.02] group"
            >
              <div className="p-8">
                {/* Article Header */}
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center space-x-4 flex-wrap">
                    <span className={`px-3 py-1 text-sm font-bold rounded-full ${getEvidenceBadgeColor(article.evidenceLevel)}`}>
                      Evidence Level {article.evidenceLevel}
                    </span>
                    <span className="px-3 py-1 text-sm font-medium bg-red-500/20 text-red-300 rounded-full border border-red-400/30">
                      {article.category}
                    </span>
                    <span className="px-3 py-1 text-sm font-medium bg-blue-500/20 text-blue-300 rounded-full border border-blue-400/30">
                      {article.specialty}
                    </span>
                    {/* Journal Badge */}
                    <span className={`px-3 py-1 text-xs font-medium rounded-full ${getJournalColor(article.journal || 'The Lancet')}`}>
                      {article.journal || 'The Lancet'}
                    </span>
                    {/* Data Source Badge */}
                    <span className={`px-3 py-1 text-xs font-medium rounded-full flex items-center space-x-1 ${getSourceColor(article.source)}`}>
                      {getSourceIcon(article.source)}
                      <span>{article.source === 'lancet' ? 'Lancet直接' : 'PubMed経由'}</span>
                    </span>
                    {article.isOpenAccess && (
                      <span className="px-3 py-1 text-sm font-medium bg-green-500/20 text-green-300 rounded-full border border-green-400/30">
                        Open Access
                      </span>
                    )}
                    {/* New Article Indicator */}
                    {new Date(article.publishDate) > new Date(Date.now() - 24 * 60 * 60 * 1000) && (
                      <span className="px-3 py-1 text-sm font-bold bg-yellow-500/20 text-yellow-300 rounded-full border border-yellow-400/30 animate-pulse">
                        NEW
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-300">
                      <Star className="h-5 w-5" />
                    </button>
                    <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-300">
                      <Download className="h-5 w-5" />
                    </button>
                    <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-xl transition-all duration-300">
                      <Share2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-red-200 transition-colors cursor-pointer"
                    onClick={() => handleArticleClick(article)}>
                  {article.title}
                </h3>

                {/* Authors */}
                <div className="flex items-center space-x-2 text-white/80 mb-4">
                  <Users className="h-4 w-4" />
                  <span className="text-sm">
                    {article.authors.slice(0, 3).join(', ')}
                    {article.authors.length > 3 && ` et al. (${article.authors.length} authors)`}
                  </span>
                </div>

                {/* Publication Info */}
                <div className="flex items-center space-x-6 text-sm text-white/70 mb-6">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>{article.publishDate}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <BookOpen className="h-4 w-4" />
                    <span>Vol. {article.volume}, No. {article.issue}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="h-4 w-4" />
                    <span>{article.readingTime}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <TrendingUp className="h-4 w-4" />
                    <span>{article.citationCount} citations</span>
                  </div>
                </div>

                {/* Summary */}
                <p className="text-white/90 leading-relaxed mb-6 text-lg">
                  {article.summary}
                </p>

                {/* Keywords */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {article.keywords.map((keyword, index) => (
                    <span 
                      key={index}
                      className="px-3 py-1 bg-white/10 text-white/80 rounded-full text-sm border border-white/20"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>

                {/* DOI and Actions */}
                <div className="flex justify-between items-center">
                  <div className="text-sm text-white/60">
                    <span className="font-medium">DOI: </span>
                    <a 
                      href={`https://doi.org/${article.doi}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-red-300 hover:text-red-200 transition-colors"
                    >
                      {article.doi}
                    </a>
                  </div>
                  
                  <div className="flex space-x-3">
                    <button 
                      onClick={() => handleArticleClick(article)}
                      className="px-6 py-3 bg-gradient-to-r from-red-600 to-orange-600 text-white rounded-xl hover:from-red-700 hover:to-orange-700 transition-all duration-300 transform hover:scale-105 shadow-lg font-semibold"
                    >
                      詳細を読む
                    </button>
                    {article.url && (
                      <a
                        href={article.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 font-semibold flex items-center space-x-2"
                      >
                        {getSourceIcon(article.source)}
                        <span>{article.source === 'lancet' ? 'Lancet で読む' : 'PubMed で読む'}</span>
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!fetchStatus.isLoading && filteredArticles.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="h-12 w-12 text-white/40 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">
            {articles.length === 0 ? 'リアルタイムデータを取得できませんでした' : '該当する論文が見つかりませんでした'}
          </h3>
          <div className="text-white/70 space-y-2">
            {articles.length === 0 ? (
              <>
                <p>The Lancet公式サイトまたはPubMed APIからのデータ取得に失敗しました</p>
                <p className="text-sm">CORS制限、ネットワーク接続、またはAPI制限が原因の可能性があります</p>
                <p className="text-sm font-medium">手動更新ボタンで再試行してください</p>
              </>
            ) : (
              <p>フィルターを変更するか、手動更新をお試しください</p>
            )}
          </div>
        </div>
      )}

      {/* Article Detail Modal */}
      {isModalOpen && selectedArticle && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              handleCloseModal();
            }
          }}
        >
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl max-w-6xl w-full max-h-[90vh] overflow-y-auto border border-white/20 shadow-2xl transform animate-slideUp">
            <div className="p-8 border-b border-white/20 bg-gradient-to-r from-red-900/20 to-orange-900/20">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4 flex-wrap">
                  <span className={`px-3 py-1 text-sm font-bold rounded-full ${getEvidenceBadgeColor(selectedArticle.evidenceLevel)}`}>
                    Evidence Level {selectedArticle.evidenceLevel}
                  </span>
                  <span className="px-3 py-1 text-sm font-medium bg-red-500/20 text-red-300 rounded-full border border-red-400/30">
                    {selectedArticle.category}
                  </span>
                  <span className={`px-3 py-1 text-xs font-medium rounded-full ${getJournalColor(selectedArticle.journal || 'The Lancet')}`}>
                    {selectedArticle.journal || 'The Lancet'}
                  </span>
                  <span className={`px-3 py-1 text-xs font-medium rounded-full flex items-center space-x-1 ${getSourceColor(selectedArticle.source)}`}>
                    {getSourceIcon(selectedArticle.source)}
                    <span>{selectedArticle.source === 'lancet' ? 'Lancet直接' : 'PubMed経由'}</span>
                  </span>
                  <span className="text-sm text-white/70">{selectedArticle.publishDate}</span>
                  {new Date(selectedArticle.publishDate) > new Date(Date.now() - 24 * 60 * 60 * 1000) && (
                    <span className="px-3 py-1 text-sm font-bold bg-yellow-500/20 text-yellow-300 rounded-full border border-yellow-400/30 animate-pulse">
                      NEW
                    </span>
                  )}
                </div>
                <button 
                  onClick={handleCloseModal}
                  className="text-white/60 hover:text-white text-2xl transform hover:scale-110 transition-all duration-300"
                >
                  ✕
                </button>
              </div>
              
              <h2 className="text-3xl font-bold text-white mb-4">{selectedArticle.title}</h2>
              
              <div className="flex items-center space-x-6 text-white/80">
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>{selectedArticle.authors.join(', ')}</span>
                </div>
              </div>
            </div>
            
            <div className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <h3 className="text-2xl font-bold text-white mb-6">要約</h3>
                  <p className="text-white/90 leading-relaxed mb-8 text-lg">
                    {selectedArticle.summary}
                  </p>
                  
                  <h3 className="text-2xl font-bold text-white mb-6">本文</h3>
                  <div className="text-white/90 leading-relaxed space-y-4">
                    {selectedArticle.fullText.split('\n').map((paragraph, index) => (
                      <p key={index} className="text-lg">{paragraph}</p>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                    <h4 className="text-lg font-bold text-white mb-4">論文情報</h4>
                    <div className="space-y-3 text-sm">
                      <div>
                        <span className="text-white/60">雑誌: </span>
                        <span className="text-white">{selectedArticle.journal || 'The Lancet'}</span>
                      </div>
                      <div>
                        <span className="text-white/60">データソース: </span>
                        <div className="flex items-center space-x-1 mt-1">
                          {getSourceIcon(selectedArticle.source)}
                          <span className="text-white">{selectedArticle.source === 'lancet' ? 'Lancet公式' : 'PubMed API'}</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-white/60">Volume: </span>
                        <span className="text-white">{selectedArticle.volume}</span>
                      </div>
                      <div>
                        <span className="text-white/60">Issue: </span>
                        <span className="text-white">{selectedArticle.issue}</span>
                      </div>
                      <div>
                        <span className="text-white/60">Pages: </span>
                        <span className="text-white">{selectedArticle.pages}</span>
                      </div>
                      <div>
                        <span className="text-white/60">DOI: </span>
                        <a 
                          href={`https://doi.org/${selectedArticle.doi}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-red-300 hover:text-red-200 transition-colors break-all"
                        >
                          {selectedArticle.doi}
                        </a>
                      </div>
                      <div>
                        <span className="text-white/60">Citations: </span>
                        <span className="text-white">{selectedArticle.citationCount}</span>
                      </div>
                      <div>
                        <span className="text-white/60">Reading Time: </span>
                        <span className="text-white">{selectedArticle.readingTime}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                    <h4 className="text-lg font-bold text-white mb-4">キーワード</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedArticle.keywords.map((keyword, index) => (
                        <span 
                          key={index}
                          className="px-3 py-1 bg-white/10 text-white/80 rounded-full text-sm border border-white/20"
                        >
                          {keyword}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    {selectedArticle.url && (
                      <a
                        href={selectedArticle.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-red-600 to-orange-600 text-white rounded-xl hover:from-red-700 hover:to-orange-700 transition-all duration-300 transform hover:scale-105 shadow-lg font-semibold"
                      >
                        <ExternalLink className="h-4 w-4" />
                        <span>{selectedArticle.source === 'lancet' ? 'Lancet で全文を読む' : 'PubMed で詳細を見る'}</span>
                      </a>
                    )}
                    <button className="w-full px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 font-semibold">
                      お気に入りに追加
                    </button>
                    <button className="w-full px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-all duration-300 transform hover:scale-105 border border-white/20 font-semibold">
                      引用情報をコピー
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LancetSection;