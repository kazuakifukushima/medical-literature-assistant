import React from 'react';
import { 
  Star, 
  Download, 
  Share2, 
  BookOpen, 
  Calendar, 
  Users,
  Volume2,
  Eye,
  ExternalLink
} from 'lucide-react';

interface Article {
  id: string;
  title: string;
  authors: string[];
  journal: string;
  journalName: string;
  publishDate: string;
  summary: string;
  evidenceLevel: 'A' | 'B' | 'C';
  specialty: string;
  isFavorited: boolean;
  readingTime: string;
  citations: number;
}

interface ArticleCardProps {
  article: Article;
  onToggleFavorite: (id: string) => void;
  onExport: (id: string) => void;
  onGenerateAudio: (id: string) => void;
}

const ArticleCard: React.FC<ArticleCardProps> = ({ 
  article, 
  onToggleFavorite, 
  onExport,
  onGenerateAudio 
}) => {
  const getEvidenceBadgeColor = (level: string) => {
    switch (level) {
      case 'A': return 'bg-green-100 text-green-800';
      case 'B': return 'bg-yellow-100 text-yellow-800';
      case 'C': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 p-6 border border-white/20 hover:bg-white/20 transform hover:scale-[1.02] group">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center space-x-3">
          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getEvidenceBadgeColor(article.evidenceLevel)}`}>
            エビデンスレベル {article.evidenceLevel}
          </span>
          <span className="px-2 py-1 text-xs font-medium bg-blue-500/20 text-blue-200 rounded-full backdrop-blur-sm">
            {article.specialty}
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onToggleFavorite(article.id)}
            className={`p-2 rounded-full transition-colors ${
              article.isFavorited 
                ? 'text-yellow-400 hover:text-yellow-300 bg-yellow-500/20' 
                : 'text-white/60 hover:text-white hover:bg-white/10'
            }`}
          >
            <Star className={`h-4 w-4 ${article.isFavorited ? 'fill-current' : ''}`} />
          </button>
          
          <button
            onClick={() => onGenerateAudio(article.id)}
            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-all duration-300"
          >
            <Volume2 className="h-4 w-4" />
          </button>
          
          <button
            onClick={() => onExport(article.id)}
            className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-all duration-300"
          >
            <Download className="h-4 w-4" />
          </button>
          
          <button className="p-2 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-all duration-300">
            <Share2 className="h-4 w-4" />
          </button>
        </div>
      </div>
      
      <h3 className="text-xl font-bold text-white mb-3 line-clamp-2 group-hover:text-blue-200 transition-colors">
        {article.title}
      </h3>
      
      <div className="flex items-center space-x-4 text-sm text-white/70 mb-4">
        <div className="flex items-center space-x-1">
          <Users className="h-4 w-4" />
          <span>{article.authors.slice(0, 2).join(', ')}{article.authors.length > 2 ? ' et al.' : ''}</span>
        </div>
        <div className="flex items-center space-x-1">
          <BookOpen className="h-4 w-4" />
          <span>{article.journal}</span>
        </div>
        <div className="flex items-center space-x-1">
          <Calendar className="h-4 w-4" />
          <span>{article.publishDate}</span>
        </div>
      </div>
      
      <p className="text-white/80 mb-6 line-clamp-3 leading-relaxed">
        {article.summary}
      </p>
      
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4 text-sm text-white/60">
          <div className="flex items-center space-x-1">
            <Eye className="h-4 w-4" />
            <span>{article.readingTime}</span>
          </div>
          <div className="flex items-center space-x-1">
            <ExternalLink className="h-4 w-4" />
            <span>{article.citations} citations</span>
          </div>
        </div>
        
        <button className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 text-sm font-semibold transform hover:scale-105 shadow-lg">
          詳細を見る
        </button>
      </div>
    </div>
  );
};

export default ArticleCard;