import React from 'react';
import { TrendingUp, BarChart3, PieChart, Activity, Calendar, Users } from 'lucide-react';

const Analytics: React.FC = () => {
  const trendData = [
    { month: '8月', articles: 324, citations: 3250, impactScore: 8.2 },
    { month: '9月', articles: 356, citations: 4180, impactScore: 8.7 },
    { month: '10月', articles: 389, citations: 4900, impactScore: 9.1 },
    { month: '11月', articles: 423, citations: 5450, impactScore: 9.4 },
    { month: '12月', articles: 467, citations: 6200, impactScore: 9.8 },
  ];

  const specialtyData = [
    { specialty: '腫瘍科', count: 89, percentage: 28, growth: '+25%' },
    { specialty: '神経内科', count: 76, percentage: 24, growth: '+18%' },
    { specialty: '循環器科', count: 58, percentage: 18, growth: '+12%' },
    { specialty: '感染症科', count: 45, percentage: 14, growth: '+35%' },
    { specialty: '眼科', count: 32, percentage: 10, growth: '+42%' },
    { specialty: 'その他', count: 18, percentage: 6, growth: '+8%' },
  ];

  const topKeywords = [
    { keyword: 'CRISPR遺伝子治療', count: 156, trend: '+45%', category: '遺伝子医学' },
    { keyword: 'AI創薬', count: 134, trend: '+38%', category: 'デジタルヘルス' },
    { keyword: '個別化医療', count: 128, trend: '+32%', category: '精密医療' },
    { keyword: '異種移植', count: 98, trend: '+28%', category: '移植医学' },
    { keyword: 'mRNAワクチン', count: 87, trend: '+25%', category: 'ワクチン学' },
    { keyword: 'デジタル治療', count: 76, trend: '+42%', category: 'デジタルヘルス' },
    { keyword: '幹細胞治療', count: 65, trend: '+35%', category: '再生医学' },
    { keyword: 'ロボット手術', count: 54, trend: '+22%', category: '外科技術' },
  ];

  const emergingTechnologies = [
    { tech: 'AI診断支援', adoption: 78, papers: 234, impact: 'High' },
    { tech: '遠隔医療', adoption: 65, papers: 189, impact: 'High' },
    { tech: 'ウェアラブルデバイス', adoption: 52, papers: 156, impact: 'Medium' },
    { tech: 'VR/AR医療', adoption: 34, papers: 98, impact: 'Medium' },
    { tech: 'ブロックチェーン', adoption: 18, papers: 45, impact: 'Low' },
  ];

  const globalCollaborations = [
    { region: '北米', collaborations: 145, topPartner: 'NIH', growth: '+15%' },
    { region: 'ヨーロッパ', collaborations: 132, topPartner: 'EMA', growth: '+12%' },
    { region: 'アジア太平洋', collaborations: 98, topPartner: 'RIKEN', growth: '+28%' },
    { region: '中東・アフリカ', collaborations: 34, topPartner: 'WHO', growth: '+35%' },
    { region: '南米', collaborations: 23, topPartner: 'FIOCRUZ', growth: '+18%' },
  ];

  return (
    <div className="p-6 space-y-6 relative">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-white via-blue-200 to-purple-200 bg-clip-text text-transparent">トレンド分析</h2>
        <div className="flex items-center space-x-2 text-sm text-white/70 bg-white/10 px-3 py-1 rounded-full backdrop-blur-sm">
          <Calendar className="h-4 w-4" />
          <span>分析期間: 2024年8月 - 12月</span>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 group">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white/70 group-hover:text-white transition-colors">総論文数</p>
              <p className="text-3xl font-bold text-white">2,847</p>
              <p className="text-sm text-green-400 font-semibold">+24% 前月比</p>
            </div>
            <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-4 rounded-2xl shadow-lg transform group-hover:scale-110 transition-all duration-300">
              <BarChart3 className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 group">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white/70 group-hover:text-white transition-colors">平均引用数</p>
              <p className="text-3xl font-bold text-white">287</p>
              <p className="text-sm text-green-400 font-semibold">+18% 前月比</p>
            </div>
            <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-4 rounded-2xl shadow-lg transform group-hover:scale-110 transition-all duration-300">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 group">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white/70 group-hover:text-white transition-colors">国際共同研究</p>
              <p className="text-3xl font-bold text-white">432</p>
              <p className="text-sm text-green-400 font-semibold">+32% 前月比</p>
            </div>
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-4 rounded-2xl shadow-lg transform group-hover:scale-110 transition-all duration-300">
              <Users className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 group">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white/70 group-hover:text-white transition-colors">インパクトスコア</p>
              <p className="text-3xl font-bold text-white">9.8</p>
              <p className="text-sm text-green-400 font-semibold">+12% 前月比</p>
            </div>
            <div className="bg-gradient-to-r from-orange-500 to-red-500 p-4 rounded-2xl shadow-lg transform group-hover:scale-110 transition-all duration-300">
              <Activity className="h-6 w-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trend Chart */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-6">月別論文数・インパクトスコアの推移</h3>
          <div className="space-y-4">
            {trendData.map((data, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-semibold text-white w-12">{data.month}</span>
                  <div className="flex-1 bg-white/20 rounded-full h-4 w-48 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-purple-500 h-4 rounded-full transition-all duration-500 shadow-lg"
                      style={{ width: `${(data.articles / 500) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-white">{data.articles}</p>
                  <p className="text-xs text-white/70">IS: {data.impactScore}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Specialty Distribution */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-6">専門分野別論文数・成長率</h3>
          <div className="space-y-4">
            {specialtyData.map((data, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-semibold text-white w-24">{data.specialty}</span>
                  <div className="flex-1 bg-white/20 rounded-full h-4 w-32 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-teal-500 to-green-500 h-4 rounded-full transition-all duration-500 shadow-lg"
                      style={{ width: `${data.percentage}%` }}
                    ></div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-white">{data.count}</p>
                  <p className="text-xs text-green-400 font-bold">{data.growth}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Keywords */}
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-white mb-6">注目キーワード・研究領域</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {topKeywords.map((keyword, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gradient-to-r from-white/10 to-blue-500/20 rounded-xl border border-white/20 backdrop-blur-sm hover:from-white/20 hover:to-blue-500/30 transition-all duration-300 transform hover:scale-105">
              <div>
                <p className="font-bold text-white">{keyword.keyword}</p>
                <p className="text-sm text-white/80">{keyword.count} 件 • {keyword.category}</p>
              </div>
              <div className="flex items-center space-x-1">
                <TrendingUp className="h-4 w-4 text-green-400" />
                <span className="text-sm font-bold text-green-400">{keyword.trend}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Emerging Technologies */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-6">新興技術の導入状況</h3>
          <div className="space-y-4">
            {emergingTechnologies.map((tech, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">{tech.tech}</span>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-white/80 font-semibold">{tech.adoption}%</span>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      tech.impact === 'High' ? 'bg-red-500/20 text-red-300 border border-red-400/30' :
                      tech.impact === 'Medium' ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-400/30' :
                      'bg-green-500/20 text-green-300 border border-green-400/30'
                    }`}>
                      {tech.impact}
                    </span>
                  </div>
                </div>
                <div className="w-full bg-white/20 rounded-full h-3 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-indigo-500 to-purple-500 h-3 rounded-full transition-all duration-500 shadow-lg"
                    style={{ width: `${tech.adoption}%` }}
                  ></div>
                </div>
                <p className="text-xs text-white/70 font-medium">{tech.papers} 論文</p>
              </div>
            ))}
          </div>
        </div>

        {/* Global Collaborations */}
        <div className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-2xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-6">国際共同研究の動向</h3>
          <div className="space-y-4">
            {globalCollaborations.map((collab, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
                <div>
                  <p className="font-bold text-white">{collab.region}</p>
                  <p className="text-sm text-white/80">主要パートナー: {collab.topPartner}</p>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold text-white">{collab.collaborations}</p>
                  <p className="text-sm text-green-400 font-bold">{collab.growth}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;