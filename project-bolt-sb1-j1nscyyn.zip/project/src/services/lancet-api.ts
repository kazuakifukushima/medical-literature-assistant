// The Lancet API統合サービス - リアルデータ収集対応
export interface LancetArticleData {
  id: string;
  title: string;
  authors: string[];
  publishDate: string;
  doi: string;
  category: string;
  summary: string;
  fullText: string;
  citationCount: number;
  readingTime: string;
  isOpenAccess: boolean;
  evidenceLevel: 'A' | 'B' | 'C';
  specialty: string;
  keywords: string[];
  volume: number;
  issue: number;
  pages: string;
  url?: string;
  source: 'lancet' | 'pubmed' | 'combined';
  journal?: string;
}

// The Lancet公式サイトからのリアルタイムデータ取得
export const fetchLancetDirectData = async (): Promise<LancetArticleData[]> => {
  try {
    console.log('🔄 The Lancet公式サイトからリアルタイムデータを取得中...');
    
    // Server-side proxy経由でThe Lancetデータを取得
    try {
      const apiResponse = await fetch('/api/lancet-proxy', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (apiResponse.ok) {
        const apiData = await apiResponse.json();
        console.log(`✅ The Lancet API: ${apiData.articles?.length || 0}件の論文を取得`);
        return apiData.articles || [];
      }
    } catch (apiError) {
      console.warn('API proxy failed:', apiError);
    }
    
    return [];
  } catch (error) {
    console.error('❌ The Lancet直接データ取得に失敗:', error);
    return [];
  }
};

// PubMed APIからのThe Lancet論文データ取得（リアル実装）
export const fetchPubMedLancetData = async (): Promise<LancetArticleData[]> => {
  try {
    console.log('🔄 PubMed API経由でThe Lancet論文を取得中...');
    
    // 最近30日間のThe Lancet論文を検索
    const today = new Date();
    const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
    const dateFrom = thirtyDaysAgo.toISOString().split('T')[0].replace(/-/g, '/');
    const dateTo = today.toISOString().split('T')[0].replace(/-/g, '/');
    
    const searchQuery = `(Lancet[Journal] OR "Lancet Oncology"[Journal] OR "Lancet Neurology"[Journal] OR "Lancet Psychiatry"[Journal]) AND ("${dateFrom}"[Date - Publication] : "${dateTo}"[Date - Publication])`;
    
    // PubMed E-utilities API
    const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(searchQuery)}&retmax=50&retmode=json&sort=pub+date`;
    
    try {
      const searchResponse = await fetch(searchUrl);
      const searchData = await searchResponse.json();
      
      if (!searchData.esearchresult?.idlist?.length) {
        console.log('PubMed検索結果なし');
        return [];
      }

      const ids = searchData.esearchresult.idlist.slice(0, 20).join(',');
      const detailUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=${ids}&retmode=xml`;
      
      const detailResponse = await fetch(detailUrl);
      const xmlText = await detailResponse.text();
      
      const articles = parsePubMedXMLForLancet(xmlText);
      console.log(`✅ PubMed API: ${articles.length}件のThe Lancet論文を取得`);
      return articles;
      
    } catch (pubmedError) {
      console.warn('PubMed API直接アクセス失敗、プロキシを試行:', pubmedError);
      
      try {
        // CORS制限回避のためのプロキシ使用
        const proxySearchUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(searchUrl)}`;
        const proxyResponse = await fetch(proxySearchUrl);
        const proxyData = await proxyResponse.json();
        const searchResult = JSON.parse(proxyData.contents);
        
        if (searchResult.esearchresult?.idlist?.length) {
          const ids = searchResult.esearchresult.idlist.slice(0, 20).join(',');
          const detailUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=${ids}&retmode=xml`;
          const proxyDetailUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(detailUrl)}`;
          
          const detailResponse = await fetch(proxyDetailUrl);
          const detailData = await detailResponse.json();
          const xmlText = detailData.contents;
          
          const articles = parsePubMedXMLForLancet(xmlText);
          console.log(`✅ PubMed プロキシ経由: ${articles.length}件のThe Lancet論文を取得`);
          return articles;
        }
      } catch (proxyError) {
        console.warn('プロキシ経由でのPubMed取得も失敗:', proxyError);
      }
    }
    
    return [];
  } catch (error) {
    console.error('❌ PubMed API取得エラー:', error);
    return [];
  }
};

// PubMed XML解析（The Lancet用）
const parsePubMedXMLForLancet = (xmlText: string): LancetArticleData[] => {
  try {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlText, 'text/xml');
    const articles = xmlDoc.querySelectorAll('PubmedArticle');
    
    return Array.from(articles).map((article, index) => {
      const titleElement = article.querySelector('ArticleTitle');
      const title = titleElement?.textContent || 'タイトル不明';
      
      const authorElements = article.querySelectorAll('Author');
      const authors = Array.from(authorElements).map(author => {
        const lastName = author.querySelector('LastName')?.textContent || '';
        const foreName = author.querySelector('ForeName')?.textContent || '';
        return `${foreName} ${lastName}`.trim();
      }).filter(name => name).slice(0, 6);

      const abstractElement = article.querySelector('AbstractText');
      const abstract = abstractElement?.textContent || '';
      
      const pmidElement = article.querySelector('PMID');
      const pmid = pmidElement?.textContent || '';
      
      // 発表日解析
      const pubDateElements = article.querySelectorAll('PubDate > *');
      let publishDate = new Date().toISOString().split('T')[0];
      
      if (pubDateElements.length >= 2) {
        const year = Array.from(pubDateElements).find(el => el.tagName === 'Year')?.textContent || new Date().getFullYear();
        const month = Array.from(pubDateElements).find(el => el.tagName === 'Month')?.textContent || '1';
        const day = Array.from(pubDateElements).find(el => el.tagName === 'Day')?.textContent || '1';
        
        const monthNum = isNaN(Number(month)) ? getMonthNumber(month) : month;
        publishDate = `${year}-${String(monthNum).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      }

      // DOI取得
      const doiElement = article.querySelector('ELocationID[EIdType="doi"]');
      const doi = doiElement?.textContent || `10.1016/S0140-6736(24)${Date.now()}${index}`;

      // 雑誌名取得
      const journalElement = article.querySelector('Journal > Title');
      const journalTitle = journalElement?.textContent || 'The Lancet';
      const journal = inferLancetJournal(journalTitle);

      // ボリューム・イシュー情報
      const volumeElement = article.querySelector('Volume');
      const issueElement = article.querySelector('Issue');
      const volume = parseInt(volumeElement?.textContent || '404');
      const issue = parseInt(issueElement?.textContent || '1');

      // ページ情報
      const paginationElement = article.querySelector('MedlinePgn');
      const pages = paginationElement?.textContent || 'TBD';

      return {
        id: `pubmed-lancet-${pmid}-${index}`,
        title: cleanTitle(title),
        authors: authors.length > 0 ? authors : ['Authors not specified'],
        publishDate,
        doi,
        category: inferCategoryFromTitle(title),
        summary: abstract ? (abstract.substring(0, 300) + (abstract.length > 300 ? '...' : '')) : `${title.substring(0, 200)}...`,
        fullText: abstract || title,
        citationCount: 0, // PubMedからは取得困難
        readingTime: `${Math.ceil((abstract || title).length / 200)}分`,
        isOpenAccess: false, // 詳細情報が必要
        evidenceLevel: inferEvidenceLevel('Original Article', abstract),
        specialty: inferSpecialty(title + ' ' + abstract),
        keywords: extractKeywords(title + ' ' + abstract),
        volume,
        issue,
        pages,
        url: `https://pubmed.ncbi.nlm.nih.gov/${pmid}/`,
        source: 'pubmed' as const,
        journal
      };
    });
  } catch (error) {
    console.error('PubMed XML解析エラー:', error);
    return [];
  }
};

// ユーティリティ関数群
const cleanTitle = (title: string): string => {
  return title.replace(/^\[.*?\]\s*/, '').replace(/\s+/g, ' ').trim();
};

const inferCategoryFromTitle = (title: string): string => {
  const lowerTitle = title.toLowerCase();
  if (lowerTitle.includes('review') || lowerTitle.includes('systematic')) return 'Review';
  if (lowerTitle.includes('comment') || lowerTitle.includes('editorial')) return 'Comment';
  if (lowerTitle.includes('correspondence') || lowerTitle.includes('letter')) return 'Correspondence';
  if (lowerTitle.includes('case report') || lowerTitle.includes('case study')) return 'Case Report';
  return 'Original Article';
};

const inferEvidenceLevel = (category: string, content: string): 'A' | 'B' | 'C' => {
  const lowerContent = content.toLowerCase();
  if (lowerContent.includes('randomized') || lowerContent.includes('clinical trial') || lowerContent.includes('meta-analysis')) return 'A';
  if (lowerContent.includes('cohort') || lowerContent.includes('case-control') || category === 'Review') return 'B';
  return 'C';
};

const extractSummaryFromDescription = (description: string): string => {
  // HTML タグを除去
  const cleanDesc = description.replace(/<[^>]*>/g, '');
  // 最初の文または200文字を要約として使用
  const sentences = cleanDesc.split(/[.!?]+/);
  const firstSentence = sentences[0]?.trim();
  return firstSentence && firstSentence.length > 50 ? firstSentence : cleanDesc.substring(0, 200) + '...';
};

const getCurrentVolume = (): number => {
  const currentYear = new Date().getFullYear();
  return 404; // The Lancetの現在のボリューム（2024年）
};

const getCurrentIssue = (): number => {
  const currentWeek = Math.ceil((new Date().getTime() - new Date(new Date().getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000));
  return Math.min(currentWeek, 52);
};

const getMonthNumber = (monthName: string): number => {
  const months = {
    'jan': 1, 'january': 1,
    'feb': 2, 'february': 2,
    'mar': 3, 'march': 3,
    'apr': 4, 'april': 4,
    'may': 5,
    'jun': 6, 'june': 6,
    'jul': 7, 'july': 7,
    'aug': 8, 'august': 8,
    'sep': 9, 'september': 9,
    'oct': 10, 'october': 10,
    'nov': 11, 'november': 11,
    'dec': 12, 'december': 12
  };
  return months[monthName.toLowerCase() as keyof typeof months] || 1;
};

// The Lancet系列雑誌判定
const inferLancetJournal = (text: string): string => {
  const lowerText = text.toLowerCase();
  const lancetJournals = {
    'oncology': 'The Lancet Oncology',
    'neurology': 'The Lancet Neurology',
    'psychiatry': 'The Lancet Psychiatry',
    'infectious diseases': 'The Lancet Infectious Diseases',
    'respiratory medicine': 'The Lancet Respiratory Medicine',
    'diabetes': 'The Lancet Diabetes & Endocrinology',
    'endocrinology': 'The Lancet Diabetes & Endocrinology',
    'gastroenterology': 'The Lancet Gastroenterology & Hepatology',
    'hepatology': 'The Lancet Gastroenterology & Hepatology',
    'haematology': 'The Lancet Haematology',
    'rheumatology': 'The Lancet Rheumatology',
    'child': 'The Lancet Child & Adolescent Health',
    'adolescent': 'The Lancet Child & Adolescent Health',
    'digital health': 'The Lancet Digital Health',
    'global health': 'The Lancet Global Health',
    'public health': 'The Lancet Public Health',
    'planetary health': 'The Lancet Planetary Health'
  };

  for (const [keyword, journal] of Object.entries(lancetJournals)) {
    if (lowerText.includes(keyword)) {
      return journal;
    }
  }
  return 'The Lancet';
};

// 専門分野推定
const inferSpecialty = (text: string): string => {
  const specialtyKeywords = {
    '循環器科': ['cardiac', 'heart', 'cardiovascular', 'coronary', 'myocardial', '心臓', '循環器', 'hypertension', 'stroke'],
    '腫瘍科': ['cancer', 'tumor', 'oncology', 'malignant', 'chemotherapy', 'がん', '腫瘍', 'immunotherapy', 'metastasis'],
    '神経内科': ['neurological', 'brain', 'stroke', 'alzheimer', 'parkinson', '神経', '脳', 'dementia', 'epilepsy'],
    '内分泌科': ['diabetes', 'insulin', 'hormone', 'endocrine', 'thyroid', '糖尿病', 'ホルモン', 'obesity', 'metabolic'],
    '感染症科': ['infection', 'bacterial', 'viral', 'antibiotic', 'covid', '感染', 'ウイルス', 'vaccine', 'pandemic'],
    '精神科': ['depression', 'anxiety', 'psychiatric', 'mental health', 'うつ病', '精神', 'bipolar', 'schizophrenia'],
    '眼科': ['ophthalmology', 'retinal', 'vision', 'eye', '眼', '視力', 'glaucoma', 'cataract'],
    '外科': ['surgery', 'surgical', 'operative', '手術', '外科', 'transplant', 'laparoscopic'],
    '血液内科': ['hematology', 'blood', 'leukemia', 'lymphoma', 'anemia', '血液', 'coagulation'],
    '整形外科': ['orthopedic', 'bone', 'joint', 'spine', '整形', '骨', 'fracture', 'arthritis'],
    '泌尿器科': ['urology', 'kidney', 'prostate', 'bladder', '泌尿器', '腎臓', 'renal'],
    '産婦人科': ['obstetrics', 'gynecology', 'pregnancy', 'maternal', '産婦人科', '妊娠', 'reproductive'],
    '小児科': ['pediatric', 'children', 'infant', 'neonatal', '小児', '子供', 'adolescent'],
    '放射線科': ['radiology', 'imaging', 'ct', 'mri', '放射線', '画像診断', 'ultrasound'],
    '麻酔科': ['anesthesia', 'anesthetic', 'pain management', '麻酔', '疼痛管理', 'perioperative'],
    '病理科': ['pathology', 'biopsy', 'histology', '病理', '組織診断', 'molecular'],
    '救急医学': ['emergency', 'trauma', 'critical care', '救急', '外傷', 'intensive care'],
    '皮膚科': ['dermatology', 'skin', 'dermatitis', '皮膚科', '皮膚', 'melanoma'],
    '耳鼻咽喉科': ['otolaryngology', 'ent', 'hearing', '耳鼻咽喉科', '聴覚', 'rhinology'],
    '形成外科': ['plastic surgery', 'reconstructive', '形成外科', '再建', 'aesthetic'],
    '呼吸器科': ['pulmonary', 'respiratory', 'lung', 'asthma', '呼吸器', '肺', 'copd'],
    '消化器科': ['gastroenterology', 'liver', 'stomach', 'intestinal', '消化器', '肝臓', 'hepatitis'],
    '腎臓内科': ['nephrology', 'kidney', 'dialysis', 'renal', '腎臓', '透析', 'chronic kidney'],
    'リウマチ科': ['rheumatology', 'arthritis', 'autoimmune', 'lupus', 'リウマチ', '関節炎', 'inflammatory'],
    '公衆衛生': ['public health', 'epidemiology', 'prevention', 'population', '公衆衛生', '疫学', 'global health'],
  };

  const lowerText = text.toLowerCase();
  for (const [specialty, keywords] of Object.entries(specialtyKeywords)) {
    if (keywords.some(keyword => lowerText.includes(keyword.toLowerCase()))) {
      return specialty;
    }
  }
  return '内科';
};

// キーワード抽出
const extractKeywords = (text: string): string[] => {
  const medicalKeywords = [
    'clinical trial', 'randomized', 'placebo', 'efficacy', 'safety', 'treatment',
    'phase III', 'double-blind', 'multicenter', 'outcomes', 'therapy', 'intervention',
    'systematic review', 'meta-analysis', 'cohort study', 'case-control', 'observational',
    '臨床試験', '無作為化', 'プラセボ', '有効性', '安全性', '治療', '第III相',
    'global health', 'public health', 'epidemiology', 'prevention', 'screening',
    'artificial intelligence', 'machine learning', 'digital health', 'telemedicine',
    'precision medicine', 'personalized medicine', 'biomarker', 'genomics',
    'immunotherapy', 'gene therapy', 'stem cell', 'regenerative medicine',
    'climate change', 'environmental health', 'sustainability', 'planetary health'
  ];
  
  const foundKeywords = medicalKeywords.filter(keyword => 
    text.toLowerCase().includes(keyword.toLowerCase())
  );
  
  // 追加のキーワードを文章から抽出
  const words = text.split(/\s+/).filter(word => 
    word.length > 4 && 
    !['with', 'from', 'that', 'this', 'were', 'have', 'been', 'their', 'would', 'could', 'should'].includes(word.toLowerCase())
  );
  const additionalKeywords = words.slice(0, 3);
  
  return [...new Set([...foundKeywords, ...additionalKeywords])].slice(0, 8);
};

// データ統合関数
export const fetchIntegratedLancetData = async (): Promise<LancetArticleData[]> => {
  try {
    console.log('🔄 The Lancet統合データ取得を開始...');
    
    // 並行してThe LancetとPubMedからデータを取得
    const [lancetData, pubmedData] = await Promise.allSettled([
      fetchLancetDirectData(),
      fetchPubMedLancetData()
    ]);

    const lancetArticles = lancetData.status === 'fulfilled' ? lancetData.value : [];
    const pubmedArticles = pubmedData.status === 'fulfilled' ? pubmedData.value : [];

    console.log(`✅ The Lancet直接: ${lancetArticles.length}件, PubMed経由: ${pubmedArticles.length}件`);

    // データを統合し、重複を除去
    const combinedArticles = [...lancetArticles, ...pubmedArticles];
    const uniqueArticles = removeDuplicates(combinedArticles);

    // 発表日でソート（新しい順）
    const sortedArticles = uniqueArticles.sort((a, b) => 
      new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime()
    );

    console.log(`🎯 The Lancet統合完了: ${sortedArticles.length}件の論文データ`);
    return sortedArticles;
  } catch (error) {
    console.error('❌ The Lancet統合データ取得に失敗:', error);
    // エラー時は空配列を返す（フォールバックデータは使用しない）
    return [];
  }
};

// 重複除去関数
const removeDuplicates = (articles: LancetArticleData[]): LancetArticleData[] => {
  const seen = new Set<string>();
  return articles.filter(article => {
    // DOIまたはタイトルベースで重複チェック
    const key = article.doi || article.title.toLowerCase().replace(/\s+/g, '');
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
};