import React, { useState } from 'react';
import MedicalLiteratureSystem from './components/MedicalLiteratureSystem';

function App() {
  return (
    <MedicalLiteratureSystem />
  );
}

export default App;